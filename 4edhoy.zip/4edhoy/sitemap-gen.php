<?php 
global $siteurl,$themeurl,$wpdb; 
header("HTTP/1.1 200 OK"); 
// header("If-Modified-Since : ".date('l, j F Y h:i:s T')."");
header('Content-type: text/xml');
echo '<?xml version="1.0" encoding="UTF-8"?><?xml-stylesheet type="text/xsl" href="'.$themeurl.'/sitemap.xsl"?><!-- sitemap-generator-url="http://www.arnebrachhold.de" sitemap-generator-version="4.0.7.1" -->'."\n".
'<!-- generated-on="'.date('F d, Y h:i a').'" -->'."\n";

echo '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

$alldb = $wpdb->get_results("SELECT * FROM `api` LIMIT 50000");

if(!empty($alldb)){
 foreach ($alldb as $i){ 
	$tit = $i->title; 
	$date = str_replace(' ','T',$i->date).'+00:00';
	$firstword = explode(' ',strtolower($tit));

echo '	<url>
		<loc>'.$siteurl.'/'.$firstword[0].'/'.sanitize_title_with_dashes($tit).'</loc>
		<lastmod>'.$date.'</lastmod>
		<changefreq>weekly</changefreq>
		<priority>0.9</priority>
	</url>'."\n";
}
} else {
}
echo '</urlset>';
?>