<?php
// nambah page otomatis
 
if (isset($_GET['activated']) && is_admin()){
    add_action('init', 'create_initial_pages');
	add_action('after_switch_theme', 'create_db_table');
	add_filter('mod_rewrite_rules', 'my_htaccess_contents');
	add_action('admin_init', 'ftc_flush_rewrites');
}

function my_htaccess_contents( $rules )
{
$my_content = <<<EOD
\n
RewriteCond %{HTTP_HOST} ^www\.
RewriteRule ^(.*)$ http://%{HTTP_HOST}/$1 [R=301,L]
\n
EOD;
    return $my_content . $rules;
}

function ftc_flush_rewrites() {
 global $wp_rewrite;
 $wp_rewrite->flush_rules();
}

function create_db_table(){
	global $wpdb;
	$db_table_name = 'api';
    if($wpdb->get_var("show tables like '$db_table_name'") != $db_table_name){
		$wpdb->query("CREATE TABLE ".$db_table_name."(
				`id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, 
				`title` varchar(1024) NOT NULL, 
				`data` text NOT NULL, 
				`date` text NOT NULL, PRIMARY KEY (`id`), KEY `htitle` (`title`(1024))
				)");
	}
}
 
function create_initial_pages() {
    $pages = array(
        'sitemap-a' => 'Sitemap A',
        'sitemap-b' => 'Sitemap B',
        'sitemap-c' => 'Sitemap C',
        'sitemap-d' => 'Sitemap D',
        'sitemap-e' => 'Sitemap E',
        'sitemap-f' => 'Sitemap F',
        'sitemap-g' => 'Sitemap G',
        'sitemap-h' => 'Sitemap H',
        'sitemap-i' => 'Sitemap I',
        'sitemap-j' => 'Sitemap J',
        'sitemap-k' => 'Sitemap K',
        'sitemap-l' => 'Sitemap L',
        'sitemap-m' => 'Sitemap M',
        'sitemap-n' => 'Sitemap N',
        'sitemap-o' => 'Sitemap O',
        'sitemap-p' => 'Sitemap P',
        'sitemap-q' => 'Sitemap Q',
        'sitemap-r' => 'Sitemap R',
        'sitemap-s' => 'Sitemap S',
        'sitemap-t' => 'Sitemap T',
        'sitemap-u' => 'Sitemap U',
        'sitemap-v' => 'Sitemap V',
        'sitemap-w' => 'Sitemap W',
        'sitemap-x' => 'Sitemap X',
        'sitemap-y' => 'Sitemap Y',
        'sitemap-z' => 'Sitemap Z',
        'sitemap-1' => 'Sitemap 1',
        'sitemap-2' => 'Sitemap 2',
        'sitemap-3' => 'Sitemap 3',
        'sitemap-4' => 'Sitemap 4',
        'sitemap-5' => 'Sitemap 5',
        'sitemap-6' => 'Sitemap 6',
        'sitemap-7' => 'Sitemap 7',
        'sitemap-8' => 'Sitemap 8',
        'sitemap-9' => 'Sitemap 9',
        'sitemap-0' => 'Sitemap 0',
		'disclaimer' => 'Disclaimer',
        'contact-us' => 'Contact Us',
        'privacy-policy' => 'Privacy Policy',

    );
    foreach($pages as $key => $value) {
        $id = get_page_by_title($value);
        $page = array(
            'post_type'   => 'page',
            'post_title'  => $value,
            'post_name'   => $key,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_parent' => ''
        );
        if (!isset($id)) wp_insert_post($page);
    };
}
?>