<?php
$key = 'mannaktw';

function mannaKtw_add_admin_page(){
	add_menu_page('mannaKtw Option','mannaKtw','manage_options','mannaktw-option','mannaKtw_general_page','',110);
	add_submenu_page('mannaktw-option','mannaKtw Setting','Settings','manage_options','mannaktw-option','mannaKtw_general_page');
	add_submenu_page('mannaktw-option','mannaKtw SEO','SEO','manage_options','mannaktw-seo','mannaKtw_seo_submenu');
	
	add_action('admin_init','mannaKtw_reg_settings');
}
add_action('admin_menu','mannaKtw_add_admin_page');

function mannaKtw_reg_settings(){
	//General Option
	register_setting('mannaktw-setting','iklan_728');
	register_setting('mannaktw-setting','iklan_revhits');
	register_setting('mannaktw-setting','meta_verif');
	register_setting('mannaktw-setting','code_histats');
	add_settings_section('mannaktw-iklan','','mannaktw_iklan_option','mannaktw-option');
	add_settings_field('iklan-728','Iklan 728','mannaktw_iklan_728','mannaktw-option','mannaktw-iklan');
	add_settings_field('iklan-revhits','Iklan RevenueHits','mannaktw_iklan_revhits','mannaktw-option','mannaktw-iklan');
	add_settings_field('meta_verif','Meta Verification','mannaktw_meta_verif','mannaktw-option','mannaktw-iklan');
	add_settings_field('code_histats','Histats Counter','mannaktw_code_histats','mannaktw-option','mannaktw-iklan');
	
	//Seo Option
	register_setting('mannaktw-seo','main_keyword');
	register_setting('mannaktw-seo','white_words_1');
	register_setting('mannaktw-seo','white_words_2');
	register_setting('mannaktw-seo','white_words_3');
	register_setting('mannaktw-seo','white_words_4');
	register_setting('mannaktw-seo','white_words_5');
	register_setting('mannaktw-seo','white_words_6');
	register_setting('mannaktw-seo','white_words_7');
	register_setting('mannaktw-seo','white_words_8');
	register_setting('mannaktw-seo','white_words_9');
	register_setting('mannaktw-seo','white_words_10');
	register_setting('mannaktw-seo','white_words_11');
	register_setting('mannaktw-seo','white_words_12');
	register_setting('mannaktw-seo','white_words_13');
	register_setting('mannaktw-seo','white_words_14');
	register_setting('mannaktw-seo','white_words_15');
	register_setting('mannaktw-seo','white_words_16');
	register_setting('mannaktw-seo','white_words_17');
	register_setting('mannaktw-seo','white_words_18');
	register_setting('mannaktw-seo','white_words_19');
	register_setting('mannaktw-seo','white_words_20');
	register_setting('mannaktw-seo','white_words_21');
	register_setting('mannaktw-seo','white_words_22');
	register_setting('mannaktw-seo','white_words_23');
	register_setting('mannaktw-seo','white_words_24');
	register_setting('mannaktw-seo','white_words_25');
	register_setting('mannaktw-seo','white_words_26');
	register_setting('mannaktw-seo','white_words_27');
	register_setting('mannaktw-seo','white_words_28');
	register_setting('mannaktw-seo','white_words_29');
	register_setting('mannaktw-seo','white_words_30');
	register_setting('mannaktw-seo','white_words_31');
	register_setting('mannaktw-seo','white_words_32');
	register_setting('mannaktw-seo','white_words_33');
	register_setting('mannaktw-seo','white_words_34');
	register_setting('mannaktw-seo','white_words_35');
	register_setting('mannaktw-seo','white_words_36');
	register_setting('mannaktw-seo','white_words_37');
	register_setting('mannaktw-seo','white_words_38');
	register_setting('mannaktw-seo','white_words_39');
	register_setting('mannaktw-seo','white_words_40');
	register_setting('mannaktw-seo','home_description');
	register_setting('mannaktw-seo','home_keywords');
	register_setting('mannaktw-seo','bad_words');
	register_setting('mannaktw-seo','keywords');
	register_setting('mannaktw-seo','img_option');
	
	add_settings_section('mannaktw-seo','','mannaktw_iklan_option','mannaktw-seo-option');
	add_settings_field('main_keyword','Main Keyword','mannaktw_main_keyword','mannaktw-seo-option','mannaktw-seo');
	add_settings_field('img_option','Image Option Type','mannaktw_img_option','mannaktw-seo-option','mannaktw-seo');
	add_settings_field('white_words','White Words','mannaktw_white_words','mannaktw-seo-option','mannaktw-seo');
	add_settings_field('home_description','Home Description','mannaktw_home_description','mannaktw-seo-option','mannaktw-seo');
	add_settings_field('home_keywords','Home Keywords','mannaktw_home_keywords','mannaktw-seo-option','mannaktw-seo');
	add_settings_field('keywords','Keywords','mannaktw_kategory','mannaktw-seo-option','mannaktw-seo');
	add_settings_field('bad_words','Bad Keywords','mannaktw_bad_words','mannaktw-seo-option','mannaktw-seo');
}

//Seo Option
function mannaktw_main_keyword(){
	echo '<input type="text" name="main_keyword" value="'.get_option('main_keyword').'"/>';
}

function mannaktw_img_option(){
	echo '<input type="text" name="img_option" value="'.get_option('img_option').'"/>';
	echo '<p class="description">isi salah satu : photograph | clipart | line drawing | animated gif | transparent</p>';
}

function mannaktw_white_words(){
	echo 'Baris ke 1 &nbsp&nbsp&nbsp
		<input type="text" name="white_words_1" value="'.get_option('white_words_1').'"/> && 
		<input type="text" name="white_words_2" value="'.get_option('white_words_2').'"/><br>';
	echo 'Baris ke 2 &nbsp&nbsp&nbsp
		<input type="text" name="white_words_3" value="'.get_option('white_words_3').'"/> && 
		<input type="text" name="white_words_4" value="'.get_option('white_words_4').'"/><br>';
	echo 'Baris ke 3 &nbsp&nbsp&nbsp
		<input type="text" name="white_words_5" value="'.get_option('white_words_5').'"/> && 
		<input type="text" name="white_words_6" value="'.get_option('white_words_6').'"/><br>';
	echo 'Baris ke 4 &nbsp&nbsp&nbsp
		<input type="text" name="white_words_7" value="'.get_option('white_words_7').'"/> && 
		<input type="text" name="white_words_8" value="'.get_option('white_words_8').'"/><br>';
	echo 'Baris ke 5 &nbsp&nbsp&nbsp
		<input type="text" name="white_words_9" value="'.get_option('white_words_9').'"/> && 
		<input type="text" name="white_words_10" value="'.get_option('white_words_10').'"/><br>';
	echo 'Baris ke 6 &nbsp&nbsp&nbsp
		<input type="text" name="white_words_11" value="'.get_option('white_words_11').'"/> && 
		<input type="text" name="white_words_12" value="'.get_option('white_words_12').'"/><br>';
	echo 'Baris ke 7 &nbsp&nbsp&nbsp
		<input type="text" name="white_words_13" value="'.get_option('white_words_13').'"/> && 
		<input type="text" name="white_words_14" value="'.get_option('white_words_14').'"/><br>';
	echo 'Baris ke 8 &nbsp&nbsp&nbsp
		<input type="text" name="white_words_15" value="'.get_option('white_words_15').'"/> && 
		<input type="text" name="white_words_16" value="'.get_option('white_words_16').'"/><br>';
	echo 'Baris ke 9 &nbsp&nbsp&nbsp
		<input type="text" name="white_words_17" value="'.get_option('white_words_17').'"/> && 
		<input type="text" name="white_words_18" value="'.get_option('white_words_18').'"/><br>';
	echo 'Baris ke 10 &nbsp
		<input type="text" name="white_words_19" value="'.get_option('white_words_19').'"/> && 
		<input type="text" name="white_words_20" value="'.get_option('white_words_20').'"/><br>';
	echo 'Baris ke 11 &nbsp
		<input type="text" name="white_words_21" value="'.get_option('white_words_21').'"/> && 
		<input type="text" name="white_words_22" value="'.get_option('white_words_22').'"/><br>';
	echo 'Baris ke 12 &nbsp
		<input type="text" name="white_words_23" value="'.get_option('white_words_23').'"/> && 
		<input type="text" name="white_words_24" value="'.get_option('white_words_24').'"/><br>';
	echo 'Baris ke 13 &nbsp
		<input type="text" name="white_words_25" value="'.get_option('white_words_25').'"/> && 
		<input type="text" name="white_words_26" value="'.get_option('white_words_26').'"/><br>';
	echo 'Baris ke 14 &nbsp
		<input type="text" name="white_words_27" value="'.get_option('white_words_27').'"/> && 
		<input type="text" name="white_words_28" value="'.get_option('white_words_28').'"/><br>';
	echo 'Baris ke 15 &nbsp
		<input type="text" name="white_words_29" value="'.get_option('white_words_29').'"/> && 
		<input type="text" name="white_words_30" value="'.get_option('white_words_30').'"/><br>';
	echo 'Baris ke 16 &nbsp
		<input type="text" name="white_words_31" value="'.get_option('white_words_31').'"/> && 
		<input type="text" name="white_words_32" value="'.get_option('white_words_32').'"/><br>';
	echo 'Baris ke 17 &nbsp
		<input type="text" name="white_words_33" value="'.get_option('white_words_33').'"/> && 
		<input type="text" name="white_words_34" value="'.get_option('white_words_34').'"/><br>';
	echo 'Baris ke 18 &nbsp
		<input type="text" name="white_words_35" value="'.get_option('white_words_35').'"/> && 
		<input type="text" name="white_words_36" value="'.get_option('white_words_36').'"/><br>';
	echo 'Baris ke 19 &nbsp
		<input type="text" name="white_words_37" value="'.get_option('white_words_37').'"/> && 
		<input type="text" name="white_words_38" value="'.get_option('white_words_38').'"/><br>';
	echo 'Baris ke 20 &nbsp
		<input type="text" name="white_words_39" value="'.get_option('white_words_39').'"/> && 
		<input type="text" name="white_words_40" value="'.get_option('white_words_40').'"/>';	

}

function mannaktw_home_description(){
	echo '<textarea rows="3" cols="55" name="home_description">'.get_option('home_description').'</textarea>';
}

function mannaktw_home_keywords(){
	echo '<textarea rows="3" cols="55" name="home_keywords">'.get_option('home_keywords').'</textarea>';
	echo '<p class="description">contoh penulisan keyword 1,keyword 2, dst</p>';
}

function mannaktw_kategory(){

	echo '<textarea rows="20" cols="100" name="keywords">'.get_option('keywords').'</textarea>';
	echo '<p class="description">contoh penulisan keyword 1|keyword 2|keyword 3</p>';
}

function mannaktw_bad_words(){
	if (empty(get_option('bad_words'))){
		$bad = 'ahole|amcik|andskota|anus|arschloch|arse|ash0le|ashole|ass|asshole|assrammer|ayir|azzhole|b!+ch|b!tch|b00b|b17ch|b1tch|bassterd|bastard|basterd|bi+ch|bi7ch|biatch|bitch|blowjob|boffing|boiolas|bollock|boobs|breasts|buceta|butthole|butt-pirate|buttwipe|c0ck|cabron|cawk|cazzo|chraa|chuj|cipa|clit|cnts|cntz|cock|cocksucker|cock-sucker|crap|cum|cunt|d4mn|damn|daygo|dego|dick|dike|dild0|dildo|dilld0|dirsa|dominatricks|dominatrics|dominatrix|dupa|dyke|dziwka|ejackulate|ejakulate|ekrem|ekto|enculer|enema|faen|fag|fag1t|faget|faggit|faggot|fagit|fags|fagz|faig|faigs|fanculo|fanny|fart|fatass|fcuk|feces|feg|felcher|ficken|fitt|flikker|foreskin|fotze|fuck|fucker|fuckin|fucking|fukah|fuken|fuker|fukin|fukk|futkretzn|fux0r|g00k|gay|gayboy|gaygirl|gays|gayz|god-damned|gook|guiena|h00r|h0ar|h0r|h0re|h4x0r|hell|hells|helvete|hoar|hoer|honkey|hoor|hoore|hore|huevon|injun|jackoff|jackoff|japs|jerk-off|jisim|jism|jiss|jizm|jizz|kanker|kawk|kike|klootzak|knob|knobs|knobz|knulle|kraut|kuksuger|kunt|kunts|kuntz|kurac|kurwa|kusi|kyrpa|l3i+ch|l3itch|lesbian|lesbo|lezzian|lipshits|lipshitz|mamhoon|masochist|masokist|massterbait|masstrbait|masstrbate|masterbaiter|masterbat|masterbat3|masterbate|masterbates|masturbat|masturbate|merd|mibun|mofo|monkleigh|mothafucker|mothafuker|mothafukkah|mothafukker|motherfucker|motherfucker|mother-fucker|motherfukah|motherfuker|motherfukkah|motherfukker|mouliewop|muie|mulkku|muschi|muthafucker|muthafukah|muthafuker|muthafukkah|muthafukker|nude|toge|desah|n1gr|nastt|nazis|nepesaurio|nigga|nigger|nigger|nigger|nigur|niiger|niigr|nutsack|orafis|orgasim|orgasm|orgasum|oriface|orifice|orifiss|orospu|porn|p0rn|packi|packie|packy|paki|pakie|paky|paska|pecker|peeenus|peeenusss|peenus|peinus|pen1s|penas|penis|penus|penuus|perse|phuc|phuck|phuck|phuk|phuker|phukker|picka|pierdol|pillu|pimmel|pimpis|piss|pizda|polac|polack|polak|poonani|poontsee|poop|porn|pr0n|pr1c|pr1ck|pr1k|preteen|pula|pule|pusse|pusse|pussee|pussy|pussy|puta|puto|puuke|puuker|qahbeh|queef|queer|queers|queerz|qweers|qweerz|qweir|rautenberg|recktum|rectum|retard|sadist|scank|schaffer|scheiss|schlampe|schlong|schmuck|screw|screwing|scrotum|semen|sex|sexy|sh!+|sh!t|sh1t|sh1ter|sh1ts|sh1tter|sh1tz|sharmuta|sharmute|shemale|shipal|shit|shit|shit|shits|shitter|shitty|shity|shitz|shiz|shyt|shyte|shytty|shyty|skanck|skank|skankee|skankey|skanks|skanky|skribz|skurwysyn|slut|sluts|slutty|slutz|smut|son-of-a-bitch|sphencter|spic|spierdalaj|splooge|suka|teets|teez|testical|testicle|tits|titt|turd|twat|va1jina|vag1na|vagiina|vagina|vaj1na|vajina|vittu|vullva|vulva|w00se|w0p|wank|wetback|wh00r|wh0re|whoar|whore|wichser|xrated|xxx|yed|zabourah|voyeur|pentil|entot|toked|toge|jilboob|jilbob|montok|celana dalam|celandalam|abg|cabecabe|cabe cabe|cabe-cabe|pantat|terong|amentil|puting|cewek|nenen|http:|cache:|site:|utm_source|sex|feminine odor|rid of feminine|kaylee apartment|vagin|porn|gamble|xxx|nude|squirt|gay|abortion|attack|bomb|casino|cocaine|die|death|erection|gambling|heroin|marijuana|masturbation|pedophile|penis|poker|pussy|terrorist|nudge|hack|blackjack|software|boobs|boob|vagina|bra|breast|yahoo! groups|ensiklopedia bebas|tokobagus.com|3some|4some|amcik|anal|analingus|analplay|anal-play|androsodomy|andskota|anilingus|anus|arschloch|arse|arsehole|ass|asses|asshole|asslick|assplay|ass-playauto-eroticism|autofellatio|autopederasty|b!+ch|b!tch|b00b|b17ch|b1tch|ballgag|ball-gag|bareback|barebacking|bastard|bdsm|beastilaity|bestiality|bi+ch|bi7ch|bitch|blowjob|blow-job|blowjobs|boiolas|bollock|bondage|boner|boob|boobies|boobs|breasts|buceta|bugger|buggery|bukake|bukakke|bulldyke|bull-dyke|bulldykes|bull-dykes|butt|butt-pirate|buttplug|butt-plug|buttplugs|butt-plugs|butts|c0ck|cabron|cameltoe|cameltoes|cawk|cazzo|chick|chicks|chink|clit|clitoris|clits|cock|coprophagy|coprophilia|cornhole|cornholes|corpophilia|corpophilic|creampie|cream-pie|creamypie|cum|cumming|cumpic|cumshot|cumshots|cunilingus|cunnilingus|cunt|d4mn|deepthroat|defecated|defecating|defecation|dick|dicks|dike|dildo|dildoes|dildos|dirsa|doggystyle|douche|douches|douching|dyke|dykes|dziwka|ejackulate|ekrem|ekto|enculer|enema|enemas|erection|erections|erotic|erotica|facesit|facesitting|facial|facials|faen|fag|fags|fanculo|fanny|fart|farted|farting|fcuk|feces|felch|felcher|felching|fellatio|fetish|fetishes|ficken|fisting|flikker|footjob|foreskin|fotze|foursome|fuck|fuk|futkretzn|fux0r|gag|gangbang|gang-bang|gay|genital|genitalia|genitals|gloryhole|glory-hole|gloryholes|glory-holes|gook|groupsex|gspot|g-spot|guiena|h0r|h4x0r|handjob|hand-job|hardcore|helvete|hoer|homosexual|honkey|hore|horny|huevon|incest|intercourse|interracial|jackass|jackoff|jizz|kankerkinky|klootzak|knulle|kraut|kuksuger|kurac|kurwa|kusi|kyrpa|l3i+ch|l3itch|labia|labial|lesbian|lesbians|lesbo|lolita|lolitas|mamhoon|masochism|masochist|masochistic|masturbat|masturbate|masturbation|mibun|mofo|monkleigh|motherfisher|mouliewop|muff|muie|mulkku|muschi|naked|nazis|necrophilia|nepesaurio|nigga|nigger|niggers|nipple|nipples|nude|nudes|nudity|nutsack|nympho|nymphomania|nymphomaniac|orgasm|orgasms|orgies|orgy|orospu|p0rn|paska|pecker|pederast|pederasty|pedophilia|pedophiliac|pee|peeing|penetration|penetrations|penis|perse|pervert|perverted|perverts|phuck|picka|pierdol|pillu|pimmel|pimpis|piss|pizda|poontsee|poop|porn|pr0n|precum|preteen|prick|pricks|prostitute|prostituted|prostitutes|prostituting|pusse|pussies|pussy|pussylips|pussys|qahbeh|queef|queer|queers|qweef|rape|raped|rapes|rapist|rautenberg|rimjob|sadism|sadist|scat|schaffer|scheiss|schlampe|schmuck|screw|scrotum|semen|sex|sh!t|sharmuta|sharmute|shemale|shipal|shit|shiz|sixtynine|sixty-nine|skribz|skurwysyn|slut|sluts|slutty|smut|sodomize|sodomy|softcore|spank|spanked|spanking|sperm|sphencter|spic|spierdalaj|squirt|squirted|squirting|strapon|strap-on|submissive|suck|sucked|sucking|suck-off|sucks|teets|teez|testicle|testicles|threesome|tit|tits|titt|titties|titty|tittys|tranny|transsexual|transvestite|twat|twats|twaty|twink|upskirt|urinated|urinating|urination|vagina|vaginas|vibrator|vittu|vulva|w00se|wank|wanking|watersports|whoar|whore|whores|wtf|xrated|x-rated|zabourah|crackz|crack|nude|naked|xxx|porn|warez|no cd|nocd|sexy|sex|sexy|gay|school|hate|shit|nazi|masturbation|sucks|breas|hitler|fags|fag|babes|babe|erotic|dildo|suicide|topless|pussy|racist|nigger|lesbian|hardcore|orgy|sex|porn|bokep|memek|ngentot|lesbi|gay|nude|fuck|3gp|daniel brou|joanne yiokaris|pg ishazamuddin|sekolah menengah shan tao|dnwallace|david neil wallace|bugil|cerita seru|seks|cerita panas|cerita dewasa|hentai|xxx|setubuh|senggama|17tahun|17 tahun|nipples|incest|jebanje|lucah|ngewe|mesum|vagina|mujeres|lancap|bogel|xes|lau xanh|telanjang|akka|pemerkosaan|hot girl|toket|birahi|bangla|choda|sabul|hot video|bikini|chudai|cipki|togel|malam pertama|malam pengantin|cerita hot|tukar pasangan|tukar istri|ngecrot|kontol|maria ozawa|tanpa busana|desnuda|topless|nude|kelamin|hubungan intim|tetek|tits|kripalu|buaya|uterus|cervix|female|human|heart|body|organs|respiratory|sciatic|nerve|morte|acapulco70.com|acapulco70|yael|farache19|pewpie|pewdie|Tank Top|Clutch Bag|Wear|Paint Trees|Cartwheel|Broom|Love|Ruffles|High Heels|Clutch Bag|Inseam Shorts|Coupon|Bangs Baby|Weight Loss|private|Paint Trees|how to|hot fly fishing girls|girls|girl|fishing|hot girls|hot girl|formula for calculating menstrual cycle|menstrual|mens|men|menstruasi';
	}else{
		$bad = get_option('bad_words');
	}
	echo '<textarea rows="20" cols="100" name="bad_words">'.$bad.'</textarea>';
	echo '<p class="description">contoh penulisan badword|keyword 2|badword3 dst</p>';
}

//General Option
function mannaktw_iklan_option(){
}

function mannaktw_iklan_728(){
	echo '<textarea rows="4" cols="100" name="iklan_728">'.get_option('iklan_728').'</textarea>';
}
function mannaktw_iklan_revhits(){
	echo '<textarea rows="4" cols="100" name="iklan_revhits">'.get_option('iklan_revhits').'</textarea>';
}
function mannaktw_meta_verif(){
	echo '<textarea rows="4" cols="100" name="meta_verif">'.get_option('meta_verif').'</textarea>';
}
function mannaktw_code_histats(){
	echo '<textarea rows="4" cols="100" name="code_histats">'.get_option('code_histats').'</textarea>';
}

function mannaKtw_general_page(){
	echo '<h1>MannaKtw Options</h1>';
	settings_errors();
	echo '<form method="post" action="options.php">';
			settings_fields('mannaktw-setting');
			do_settings_sections('mannaktw-option');
			submit_button();
	echo '</form>';
}

function mannaKtw_seo_submenu(){
	echo '<h1>MannaKtw SEO Options</h1>';
	settings_errors();
	echo '<form method="post" action="options.php">';
			settings_fields('mannaktw-seo');
			do_settings_sections('mannaktw-seo-option');
			submit_button();
	echo '</form>';
}
?>