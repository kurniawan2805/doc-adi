<?php

$urlData = $_SERVER['REQUEST_URI'];
$urlData = str_ireplace('/','',$urlData);

$result = $wpdb->get_results("SELECT * FROM api WHERE title LIKE '".trim($urlData)."%' LIMIT 10");

echo '<div class="content-cont">';
echo '<div class="single-title"><h2>Archive For '.ucwords($urlData).'</h2></div>';
echo '<ul>';
if (!empty($result)){
	$i = 1;
	foreach($result as $hasil){
		if ($i>10){break;}else{
		$Judul = $hasil->title;
		$firstWord = explode(' ',$Judul);
		$DataImg = $hasil->data;
		$DataImg = explode('[.Y.]',$DataImg);shuffle($DataImg);
		$DataImg = explode('(.|.)',$DataImg[0]);
		$TitleImg = $DataImg[0];
		$URLImg = $DataImg[1];
		$content = grabContent($Judul,2);
		echo '<li>'.
			 '<div class="yt-container">'.
			 '<div class="yt">'.
			 '<div class="yt-thumb"><a href="'.$siteurl.'/'.strtolower($firstWord[0]).'/'.sanitize_title_with_dashes(strtolower($Judul)).'"><img src="'.$URLImg.'" width="196" height="110" alt="'.$TitleImg.' on '.$Judul.'" title="'.$TitleImg.' on '.$Judul.' onError="this.onerror=null;this.src=\''.$themeurl.'/images/loading.gif\';"/></a></div>'.
			 '<div class="yt-content"><h3 class="yt-title"><a href="'.$siteurl.'/'.strtolower($firstWord[0]).'/'.sanitize_title_with_dashes(strtolower($Judul)).'">'.ucwords(strtolower($Judul)).'</a></h3></div>'.
			 '<div class="">'.spinner($Name).'</div>'.
			 '<div class="">'.$content.'</div>'.
			 '</div></div>'.
			 '</li>';
		}
	}
}
echo '</ul>';
echo '</div>';
?>