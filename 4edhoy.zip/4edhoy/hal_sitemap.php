<?php

$domain      = $_SERVER['HTTP_HOST'];
$domain      = explode(".", $domain);
$domain_name = $domain[0];

$sitemap     = urldecode($_SERVER['REQUEST_URI']);
$sitemap     = str_replace(array('sitemap-','/'),'',$sitemap);

$content_about		= '<h3 class="tac mb15"><strong>'.$sitename.' - '.$sitedesc.'</strong></h3><p>Hi there, we are people who want to give you information about '.$main_keyword.' Source. Together we try to collect as detail as possible '.ucwords($main_keyword).'.</p><p>We hope '.ucwords($main_keyword).' in '.strtolower($main_keyword).' can bring you useful information. If you want to talk with us, please visit our contact page, there is detail about how to contact us. For visitor privacy, please see privacy policy section.</p><p>As noted on disclaimer page, we only distribute information about them. The designs, products and names mentioned in our listing are the property of their respective owners. We try as can as possible to give the credit via link to original resource.</p><p>Thank you for visiting us.<br>Best regards,<br>Founder</p>';

$content_contact    = '<p>Hi, in the page you will see detail about how to contact us. Because of there are so many message coming to us, it is important for you to follow the instruction below, so that your message can be delivered to our right department. We will respond your message in our nation work days and of course as soon as possible. Thank you.<p><p><strong>Ask or Information</strong><br>Subject: Ask<br>To: mail.'.$domain_name.'[at]gmail.com<br><p><p><strong>Disclaimer</strong><br>Subject: Disclaimer<br>To: mail.'.$domain_name.'[at]gmail.com<br><p><p><strong>Copyright</strong><br>Subject: Copyright<br>To: mail.'.$domain_name.'[at]gmail.com<br><p><p><strong>Advertisement</strong><br>Subject: Advertisement<br>To: mail.'.$domain_name.'[at]gmail.com</p>';

$content_privacy    = '<p>The privacy of our visitors to '.$domain_name.' is important to us. At '.$domain_name.', we recognize that privacy of your personal information is important. Here is information on what types of personal information we receive and collect when you use and visit '.$domain_name.', and how we safeguard your information. We never sell your personal information to third parties.<br><br><strong>Log Files</strong><br>As with most other websites, we collect and use the data contained in log files. The information in the log files include your IP (internet protocol) address, your ISP (internet service provider, such as AOL or Shaw Cable), the browser you used to visit our site (such as Internet Explorer, Safari, Google Chrome, or Firefox), the time you visited our site and which pages you visited throughout our site.<br><br><strong>Cookies and Web Beacons</strong><br>We do use cookies to store information, such as your personal preferences when you visit our site. This could include only showing you a popup once in your visit, or the ability to login to some of our features, such as forums.We also use third party advertisements on '.$domain_name.' to support our site. Some of these advertisers may use technology such as cookies and web beacons when they advertise on our site, which will also send these advertisers (such as Google through the Google AdSense program) information including your IP address, your ISP, the browser you used to visit our site, and in some cases, whether you have Flash installed.<br><br>This is generally used for geotargeting purposes (showing New York real estate ads to someone in New York, for example) or showing certain ads based on specific sites visited (such as showing cooking ads to someone who frequents cooking sites).<br><br><strong>DoubleClick DART cookies</strong><br>We also may use DART cookies for ad serving through Google\'s DoubleClick, which places a cookie on your computer when you are browsing the web and visit a site using DoubleClick advertising (including some Google AdSense advertisements). This cookie is used to serve ads specific to you and your interests ("interest based targeting").<br><br>The ads served will be targeted based on your previous browsing history (For example, if you have been viewing sites about visiting New York, you may see New York hotel advertisements when viewing a non-related site, such as on a site about hockey). DART uses "non personally identifiable information".<br><br><strong>A snippet from Google Adsense Website:</strong><br>"Google uses the DoubleClick cookie on publisher websites displaying AdSense for content ads. Subject to any applicable laws, rules and regulations, you will have the sole and exclusive right to use all data derived from your use of the DoubleClick cookie for any purpose related to your business, provided that Google may use and disclose this data subject to the terms of <a rel="nofollow" target="_blank" href="http://www.google.com/intl/en/privacy/ads/privacy-policy.html">Google\'s advertising privacy policies</a> and any applicable laws, rules and regulations."<br><br>It does NOT track personal information about you, such as your name, email address, physical address, telephone number, social security numbers, bank account numbers or credit card numbers. You can opt-out of this ad serving on all sites using this advertising by visiting <a rel="nofollow" target="_blank" href="http://www.doubleclick.com/privacy/dart_adserving.aspx">this link</a>.<br><br>You can chose to disable or selectively turn off our cookies or third-party cookies in your browser settings, or by managing preferences in programs such as Norton Internet Security. However, this can affect how you are able to interact with our site as well as other websites. This could include the inability to login to services or programs, such as logging into forums or accounts.<br><br>Deleting cookies does not mean you are permanently opted out of any advertising program. Unless you have settings that disallow cookies, the next time you visit a site running the advertisements, a new cookie will be added.</p>';

$content_dmca       = '<p><strong>Notification of Copyright Infringement</strong><br><br>We respect the intellectual property rights of others and expects our users to do the same. In accordance with the Digital Millennium Copyright Act of 1998, the text of which may be found on the U.S. Copyright Office website at http://www.copyright.gov/legislation/dmca.pdf, we will respond expeditiously to claims of copyright infringement committed using our service that are reported to our Designated Copyright Agent identified in the sample notice below.<br><br>If you are a copyright owner, or are authorized to act on behalf of one or authorized to act under any exclusive right under copyright, please report alleged copyright infringements taking place on or through the site and service (collectively the "Service") by completing the following DMCA Notice of Alleged Infringement and delivering it to our Designated Copyright Agent.<br><br>Upon receipt of Notice as described below, our Designated Copyright Agent will take whatever action, in its sole discretion, it deems appropriate, including removal of the challenged use from the Service and/or termination of the user\'s account in appropriate circumstances.<br><br><strong>DMCA Notice of Alleged Infringement ("Notice")</strong><br>Identify the copyrighted work that you claim has been infringed, or ? if multiple copyrighted works are covered by this Notice ? you may provide a representative list of the copyrighted works that you claim have been infringed.<br>Identify the material or link you claim is infringing (or the subject of infringing activity) and that access to which is to be disabled, including at a minimum, if applicable, the URL of the link shown on the Service where such material may be found.<br>Provide your mailing address, telephone number, and, if available, email address.<br>Include both of the following statements in the body of the Notice:<br><br>"I hereby state that I have a good faith belief that the disputed use of the copyrighted material is not authorized by the copyright owner, its agent, or the law (e.g., as a fair use)."<br><br>"I hereby state that the information in this Notice is accurate and, under penalty of perjury, that I am the owner, or authorized to act on behalf of the owner, of the copyright or of an exclusive right under the copyright that is allegedly infringed."<br><br>Provide your full legal name and your electronic or physical signature.<br>Deliver this Notice, with all items completed, to our Designated Copyright Agent:<br>Copyright Agent<br>sawyoo<br>mail.'.$domain_name.'[at]gmail.com<br><br><strong>Counter Notices</strong><br>One who has posted material that allegedly infringes a copyright may send our Designated Copyright Agent a counter notice pursuant to Sections 512(g)(2) and 512(g)(3) of the DMCA. When our Designated Copyright Agent receives a counter notice, it may in its discretion reinstate the material in question in not less than 10 nor more than 14 days after it receives the counter notice unless it first receive notice from the copyright claimant that they have filed a legal action to restrain the allegedly infringing activity.<br><br>To provide a counter notice to our Designated Copyright Agent, please return the following form to the Designated Copyright Agent. Please note that if you provide a counter notice, in accordance with the our Privacy Policy (located at the site) and the terms of the DMCA, the counter notice will be given to the complaining party.<br><br><strong>Counter Notice</strong><br>Identification of the material that has been removed or to which access has been disabled on the service and the location at which the material appeared before it was removed or access to it was disabled:<br>I hereby state under penalty of perjury that I have a good faith belief that the material was removed or disabled as a result of mistake or misidentification of the material to be removed or disabled.<br>Your name, address, telephone number and, if available, email address:<br>I hereby state that I consent to the jurisdiction of the Federal District Court for the judicial district in which my address is located or, if my address is outside of the France, for any judicial district in which we may be found, and I will accept service of process from the complaining party who notified us of the alleged infringement or an agent of such person.<br>Your physical or electronic signature (full legal name):____________________________<br><br>The Counter Notice should be delivered to our Designated Copyright Agent:<br><br>Copyright Agent<br>sawyoo<br>mail.'.$domain_name.'[at]gmail.com<br><br><strong>Notification of Trademark Infringement</strong><br><br>If you believe that your trademark (the ?Mark?) is being used by a user in a way that constitutes trademark infringement, please provide our Designated Copyright Agent (specified above) with the following information:<br><br>Your physical or electronic signature, or a physical or electronic signature of a person authorized to act on your behalf;<br>Information reasonably sufficient to permit it to contact you or your authorized agent, including a name, address, telephone number and, if available, an email address;<br>Identification of the Mark(s) alleged to have been infringed, including<br>for registered Marks, a copy of each relevant federal trademark registration certificate orfor common law or other Marks, evidence sufficient to establish your claimed rights in the Mark, including the nature of your use of the Mark, and the time period and geographic area in which the Mark has been used by you;Information reasonably sufficient to permit our Designated Copyright Agent to identify the use being challenged;<br>A statement that you have not authorized the challenged use, and that you have a good-faith belief that the challenged use is not authorized by law; and<br>A statement under penalty of perjury that all of the information in the notification is accurate and that you are the Mark owner, or are authorized to act on behalf of the Mark owner.<br><br>Upon receipt of notice as described above, our Designated Copyright Agent will seek to confirm the existence of the Mark on the Service, notify the registered user who posted the content including the Mark, and take whatever action, in its sole discretion, it deems appropriate, including temporary or permanent removal of the Mark from the Service.<br><br>A registered user may respond to notice of takedown by showing either (a) that the Mark has been cancelled, or has expired or lapsed or (b) that the registered user has a trademark registration, an unexpired license covering the use, or some other relevant right to the Mark, or (c) that the use is for other reasons shown by the registered user non-infringing. If the registered user makes an appropriate showing of either (a), (b) or (c) then our Designated Copyright Agent may exercise its discretion not to remove the Mark.<br><br>If our Designated Copyright Agent decides to comply with a takedown request, it will do so within a reasonably expeditious period of time. Notwithstanding the foregoing, our Designated Copyright Agent will comply as appropriate with the terms of any court order relating to alleged trademark infringement on the Service.<br><br><strong>Notification of Other Intellectual Property ("IP") Infringement</strong><br><br>If you believe that some other IP right of yours is being infringed by a user, please provide our Designated Copyright Agent (specified above) with the following information:<br><br>Your physical or electronic signature, or a physical or electronic signature of a person authorized to act on your behalf;Information reasonably sufficient to permit our Designated Copyright Agent to contact you or your authorized agent, including a name, address, telephone number and, if available, an email address;<br>Identification of the IP alleged to have been infringed, including (i) a complete description or explanation of the nature of the IP, (ii) evidence that you own the IP in the relevant jurisdiction, including copies of relevant patents, registrations, certifications or other documentary evidence of your ownership, and (iii) a showing sufficient for our Designated Copyright Agent to determine without unreasonable effort that the IP has been infringed;<br>Information reasonably sufficient to permit our Designated Copyright Agent to identify the use being challenged;<br>A statement that you have not authorized the challenged use, and that you have a good-faith belief that the challenged use is not authorized by law; and<br>A statement under penalty of perjury that all of the information in the notification is accurate and, that you are the IP owner, or are authorized to act on behalf of the IP owner.<br><br>Upon receipt of notice as described above, our Designated Copyright Agent will seek to confirm the existence of the IP on the Service, notify the registered user who posted the content including the IP, and take whatever action, in its sole discretion, it deems appropriate, including temporary or permanent removal of the IP from the Service.<br><br>A registered user may respond to notice of takedown by showing either (a) that the claimant does not own the IP or (b) that the IP is not infringed. If the registered user succeeds in showing either (a), (b) or (c) then our Designated Copyright Agent may exercise its discretion not to remove the IP.<br><br>If our Designated Copyright Agent decides to comply with a takedown request, it will do so within a reasonably expeditious period of time.<br><br>We Have No Obligation to Adjudicate IP Claims ? User?s Agreement to Hold Us Harmless From Claims<br><br>Claimants and users must understand that we are not an intellectual property tribunal. While we and our Designated Copyright Agent may in our discretion use the information provided in order to decide how to respond to infringement claims, we are not responsible for determining the merits of such claims.<br><br>If a user responds to a claim of infringement by providing assurances that its content is not infringing, the user agrees that if we thereafter restore or maintain the content, the user will defend and hold us harmless from any resulting claims of infringement brought against us and our Designated Copyright Agent.</p>';

$content_disclaimer = 'If you require any more information or have any questions about our site\'s disclaimer, please feel free to contact us by email at <span style="text-decoration: underline;"><span style="color: #ff0000;"><strong><a href="'.$siteurl.'/contact-us" title="Contact Us">CONTACT</a></strong></span></span>.<br><br>All the information on this website is published in good faith and for general information purpose only. <b>'.$siteurl.'</b> does not make any warranties about the completeness, reliability and accuracy of this information. Any action you take upon the information you find on this website <b>('.$siteurl.')</b>, is strictly at your own risk. <b>'.$siteurl.'</b> will not be liable for any losses and/or damages in connection with the use of our website.<br><br>From our website, you can visit other websites by following hyperlinks to such external sites. While we strive to provide only quality links to useful and ethical websites, we have no control over the content and nature of these sites. These links to other websites do not imply a recommendation for all the content found on these sites. Site owners and content may change without notice and may occur before we have the opportunity to remove a link which may have gone \'bad\'.<br><br>Please be also aware that when you leave our website, other sites may have different privacy policies and terms which are beyond our control. Please be sure to check the Privacy Policies of these sites as well as their "Terms of Service" before engaging in any business or uploading any information.<br><br><strong>CONSENT</strong><br>By using our website, you hereby consent to our disclaimer and agree to its terms.<br><br><strong>UPDATE</strong><br>This site disclaimer was last updated on: <strong><script type="text/javascript">var d=new Date();var weekday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");var monthname=new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");document.write(weekday[d.getDay()] + " ");document.write(d.getDate() + ". ");document.write(monthname[d.getMonth()] + " ");document.write(d.getFullYear());</script></strong>. Should we update, amend or make any changes to this document, those changes will be prominently posted here.';


echo '<div class="content-cont">';

if ( is_page('About Us') ) {
	/* Title */
	echo '<h1 class="st">About Us</h1>';
	/* Content */
	echo '<div class="ic">' . $content_about . '</div>';
} elseif ( is_page('Contact Us') ) {
	/* Title */
	echo '<h1 class="st">Contact Us</h1>';
	/* Content */
	echo '<div class="ic">' . $content_contact . '</div>';
} elseif ( is_page('Privacy Policy') ) {
	/* Title */
	echo '<h1 class="st">Privacy Policy</h1>';
	/* Content */
	echo '<div class="ic">' . $content_privacy . '</div>';	
} elseif ( is_page('DMCA') ) {
	/* Title */
	echo '<h1 class="st">DMCA</h1>';
	/* Content */
	echo '<div class="ic">' . $content_dmca . '</div>';
} elseif (is_page('Disclaimer')) {
	/* Title */
	echo '<h1 class="st">Disclaimer</h1>';
	/* Content */
	echo '<div class="ic">' . $content_disclaimer . '</div>';
} elseif (is_page('Sitemap')) {
	/* Title */
	echo '<h1 class="st">Sitemap</h1>';
	/* Content */
	echo '<ul class="lt">';

		$ktw_keywords = file(TEMPLATEPATH.'/qs.php');
		$alldb        = $wpdb->get_results("SELECT * FROM `api` LIMIT 50000");

		$db_key = array();
		if(!empty($alldb)){
			foreach ($alldb as $dk) { 
				$db_key[] = $dk->title;
			}
		}

		$key_from_file = (!empty($ktw_keywords)) ? $ktw_keywords : array();
		$key_from_db   = (!empty($db_key)) ? $db_key : array();
		$all_key       = array_merge($key_from_file, $key_from_db);
		$all_key       = array_unique($all_key);

		shuffle($all_key);

		if( !empty($all_key) ) {
			shuffle($all_key);
			$i = 0;
			foreach( $all_key as $keywords ) {
					$firstword = explode(' ',$keywords);
					if (!empty($url_keyword)) {
						$c_firstword = $url_keyword;
					} else {
						$c_firstword = strtolower($firstword[0]);
					}

					if (!empty($keywords)) {
						echo '<li>';
							echo '<a href="'.$siteurl.'/'.$c_firstword.'/'.sanitize_title_with_dashes(strtolower($keywords)).'" title="'.str_replace( array("\n", "\r"), '', ucwords($keywords)).'">';
								echo str_replace( array("\n", "\r"), '', ucwords($keywords));
							echo '</a>';
						echo '</li>';
					}
				$i++;
			}
		}

	echo '</ul>';
} else {
	echo '<div class="single-title"><a href="#">Sitemap Index '.ucwords($sitemap).'</a></div>';
	if (stripos($sitemap,'0-9')!== false){
		$mapSql = $wpdb->get_results("SELECT * FROM api WHERE title LIKE '0%' OR title LIKE '1%' OR title LIKE '2%' OR title LIKE '3%' OR title LIKE '4%' OR title LIKE '5%' OR title LIKE '6%' OR title LIKE '7%' OR title LIKE '8%' OR title LIKE '9%'");
	}else{
		$mapSql = $wpdb->get_results("SELECT * FROM api WHERE title LIKE '".strtolower($sitemap)."%'");
	}
	if (!empty($mapSql)){
		$i=1;$last=$wpdb->num_rows;
		foreach($mapSql as $data){
			if ($i==$last){
				$arrSitemap .= trim($data->title);
			}else{
				$arrSitemap .= trim($data->title).'|';
			}$i++;
		}
	}
	
	$ktw_keywords=file(TEMPLATEPATH.'/qs.php');
	if(!empty($ktw_keywords)){
		$i=1;$last=count($ktw_keywords);
		foreach($ktw_keywords as $keywords){
			if(strtolower($keywords[0]) == strtolower($sitemap)){
				if ($i==$last){
					$arrSitemap .= $keywords;
				}else{
					$arrSitemap .= $keywords.'|';
				}
			}$i++;
		}
	}
	
	$arrSitemaps = explode('|',$arrSitemap);
	sort($arrSitemaps);
	echo '<ul id="double">';
	if (!empty($arrSitemaps)){
		foreach ($arrSitemaps as $sitemap){
			$firstword = explode(' ',$sitemap);
			if (trim($firstword[0]) !== ''){
				echo '<li><a href = "'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($sitemap)).'">'.ucwords(strtolower($sitemap)).'</a></li>';
			}
		}
	}else{
		echo 'Sitemap Index '.$sitemap.' kosong';
	}
	echo '</ul>';
	echo '</div>';
}