<?php

/*GLOBAL VARIABEL : sidebar, header.php, footer.php (harus di globalkan)*/
$siteurl    = 'http://'.$_SERVER['HTTP_HOST'];
$sitename    = str_ireplace(array('http://','www.'),'',get_option('siteurl'));
$sitedesc   = get_option('blogdescription');
$themeurl   = get_bloginfo('template_url');

$meta_verif = get_option('meta_verif');
$code_histats = get_option('code_histats');
$iklan_revhits = get_option('iklan_revhits');
$ads728 = get_option('iklan_728');

$main_keyword = get_option('main_keyword');
$home_description = get_option('home_description');
$home_keywords = get_option('home_keywords');
$kategory = get_option('kategory');

$date=get_the_time('F d, Y');
$Name = 'Benson Fannie|Ella Brouillard|Maria Rodriquez|Brenda Botha|Maria Nieto|Alice Ferreira';

$postedName = spinner($Name);
$readySql = true;

/*BACK END*/
include(TEMPLATEPATH .'/theme_option.php');
require_once(TEMPLATEPATH .'/create_page.php') ;

/* SUGGEST KEYWORD */
function suggKeyword($term){
	/* google */
/*	$url='http://www.google.com/complete/search?output=toolbar&q='.urlencode(strtolower($term));  */
$url='http://api.bing.com/osjson.aspx?query='.urlencode(strtolower($term));
//$url='http://suggestqueries.google.com/complete/search?output=firefox&client=firefox&hl=en-US&q='.urlencode(strtolower($term));

$ua = 'Mozilla/6.0 (Windows NT 6.2; WOW64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1|Mozilla/5.0 (Windows NT 6.2; WOW64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1|Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1|Mozilla/5.0 (Windows NT 6.1; rv:15.0) Gecko/20120716 Firefox/15.0a2|Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1.16) Gecko/20120427 Firefox/15.0a1|Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20120427 Firefox/15.0a1|Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:14.0) Gecko/20120405 Firefox/14.0a1|Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20120405 Firefox/14.0a1|Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20120405 Firefox/14.0a1|Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:14.0) Gecko/20100101 Firefox/14.0.1|Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:14.0) Gecko/20100101 Firefox/14.0.1|Mozilla/5.0 (Windows; U; Windows NT 6.1; WOW64; en-US; rv:2.0.4) Gecko/20120718 AskTbAVR-IDW/3.12.5.17700 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20120403211507 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/ 20120405 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.0; rv:14.0) Gecko/20100101 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (Windows NT 6.1; de;rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (compatible; Windows; U; Windows NT 6.2; WOW64; en-US; rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.16) Gecko/20120421 Gecko Firefox/11.0|Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.16) Gecko/20120421 Firefox/11.0|Mozilla/5.0 (Windows NT 6.1; WOW64; rv:11.0) Gecko Firefox/11.0|Mozilla/5.0 (Windows NT 6.1; U;WOW64; de;rv:11.0) Gecko Firefox/11.0|Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko Firefox/11.0|Mozilla/6.0 (Macintosh; I; Intel Mac OS X 11_7_9; de-LI; rv:1.9b4) Gecko/2012010317 Firefox/10.0a4|Mozilla/5.0 (Macintosh; I; Intel Mac OS X 11_7_9; de-LI; rv:1.9b4) Gecko/2012010317 Firefox/10.0a4|Mozilla/5.0 (X11; Mageia; Linux x86_64; rv:10.0.9) Gecko/20100101 Firefox/10.0.9|Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:9.0a2) Gecko/20111101 Firefox/9.0a2|Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:9.0) Gecko/20100101 Firefox/9.0|Mozilla/5.0 (Windows NT 5.1; rv:8.0; en_us) Gecko/20100101 Firefox/8.0';
$xua = explode('|',$ua);
shuffle($xua); 
$theua = $xua[0];
$referer = 'http://www.google.com';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $theua);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_REFERER, $referer);

$hasil = curl_exec($ch);
curl_close($ch);
$hasil = json_decode($hasil);

/* if (!empty($hasil)){
	$i = 0;
	foreach ($hasil[1] as $suggdata){
		if($i==1){
			return $suggdata;
		}
		$i++;
	}
} */
return $hasil[1];

}

/* BAD WORDS BLOCK */
function badWords($word){
	$block = get_option('bad_words');
	$xblock = explode('|',$block);
	foreach ($xblock as $bl){
		$bls = ucwords($bl);
		if (stripos($word,$bls) !== false){
			$words = $bls;
			break;
			/* $arbl = array($bl,ucfirst($bl),ucwords($bl),strtoupper($bl));
			$word = str_replace($arbl,'',$word); */
		} else {
			$words = 'tidak ada';
		}
	}
	return $words;
}

function whiteWords($word){
	$w1 = get_option('white_words_1');$w2 = get_option('white_words_2');
$w3 = get_option('white_words_3');$w4 = get_option('white_words_4');
$w5 = get_option('white_words_5');$w6 = get_option('white_words_6');
$w7 = get_option('white_words_7');$w8 = get_option('white_words_8');
$w9 = get_option('white_words_9');$w10 = get_option('white_words_10');
$w11 = get_option('white_words_11');$w12 = get_option('white_words_12');
$w13 = get_option('white_words_13');$w14 = get_option('white_words_14');
$w15 = get_option('white_words_15');$w16 = get_option('white_words_16');
$w17 = get_option('white_words_17');$w18 = get_option('white_words_18');
$w19 = get_option('white_words_19');$w20 = get_option('white_words_20');
$w21 = get_option('white_words_21');$w22 = get_option('white_words_22');
$w23 = get_option('white_words_23');$w24 = get_option('white_words_24');
$w25 = get_option('white_words_25');$w26 = get_option('white_words_26');
$w27 = get_option('white_words_27');$w28 = get_option('white_words_28');
$w29 = get_option('white_words_29');$w30 = get_option('white_words_30');
$w31 = get_option('white_words_31');$w32 = get_option('white_words_32');
$w33 = get_option('white_words_33');$w34 = get_option('white_words_34');
$w35 = get_option('white_words_35');$w36 = get_option('white_words_36');
$w37 = get_option('white_words_37');$w38 = get_option('white_words_38');
$w39 = get_option('white_words_39');$w40 = get_option('white_words_40');

	if (stripos($word,$w1)!==false && stripos($word,$w2)!==false){$wwords = 'ada';}
	elseif(stripos($word,$w3)!==false && stripos($word,$w4)!==false){$wwords = 'ada';}
	elseif(stripos($word,$w5)!==false && stripos($word,$w6)!==false){$wwords = 'ada';}
	elseif(stripos($word,$w7)!==false && stripos($word,$w8)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w9)!==false && stripos($word,$w10)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w11)!==false && stripos($word,$w12)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w13)!==false && stripos($word,$w14)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w15)!==false && stripos($word,$w16)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w17)!==false && stripos($word,$w18)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w19)!==false && stripos($word,$w20)!==false){$wwords = 'ada';}
	elseif(stripos($word,$w21)!==false && stripos($word,$w22)!==false){$wwords = 'ada';}
	elseif(stripos($word,$w23)!==false && stripos($word,$w24)!==false){$wwords = 'ada';}
	elseif(stripos($word,$w25)!==false && stripos($word,$w26)!==false){$wwords = 'ada';}
	elseif(stripos($word,$w27)!==false && stripos($word,$w28)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w29)!==false && stripos($word,$w30)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w31)!==false && stripos($word,$w32)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w33)!==false && stripos($word,$w34)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w35)!==false && stripos($word,$w36)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w37)!==false && stripos($word,$w38)!==false){$wwords = 'ada';} 
	elseif(stripos($word,$w39)!==false && stripos($word,$w40)!==false){$wwords = 'ada';}
/*	elseif(stripos($word,'daihatsu')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';}
	elseif(stripos($word,'lexus')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';}
	elseif(stripos($word,'buick')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';} 
	elseif(stripos($word,'cadillac')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';} 
	elseif(stripos($word,'opel')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';} 
	elseif(stripos($word,'audi')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';} 
	elseif(stripos($word,'seat')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';} 
	elseif(stripos($word,'kia')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';} 
	elseif(stripos($word,'infiniti')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';}
	elseif(stripos($word,'citroen')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';}
	elseif(stripos($word,'dodge')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';}
	elseif(stripos($word,'rover')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';}
	elseif(stripos($word,'volvo')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';} 
	elseif(stripos($word,'jaguar')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';}
	elseif(stripos($word,'jeep')!==false && stripos($word,'wiring')!==false){$wwords = 'ada';}*/ 	
	else{
		$wwords = 'tidak ada';
	}
	return $wwords;
}

function grabContent($q,$limit){
	
$url='https://www.google.com/search?hl=en&tbm=bks&q='.urlencode($q);

$ua = 'Mozilla/6.0 (Windows NT 6.2; WOW64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1|Mozilla/5.0 (Windows NT 6.2; WOW64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1|Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1|Mozilla/5.0 (Windows NT 6.1; rv:15.0) Gecko/20120716 Firefox/15.0a2|Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1.16) Gecko/20120427 Firefox/15.0a1|Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20120427 Firefox/15.0a1|Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:14.0) Gecko/20120405 Firefox/14.0a1|Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20120405 Firefox/14.0a1|Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20120405 Firefox/14.0a1|Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:14.0) Gecko/20100101 Firefox/14.0.1|Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:14.0) Gecko/20100101 Firefox/14.0.1|Mozilla/5.0 (Windows; U; Windows NT 6.1; WOW64; en-US; rv:2.0.4) Gecko/20120718 AskTbAVR-IDW/3.12.5.17700 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20120403211507 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/ 20120405 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.0; rv:14.0) Gecko/20100101 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (Windows NT 6.1; de;rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (compatible; Windows; U; Windows NT 6.2; WOW64; en-US; rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.16) Gecko/20120421 Gecko Firefox/11.0|Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.16) Gecko/20120421 Firefox/11.0|Mozilla/5.0 (Windows NT 6.1; WOW64; rv:11.0) Gecko Firefox/11.0|Mozilla/5.0 (Windows NT 6.1; U;WOW64; de;rv:11.0) Gecko Firefox/11.0|Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko Firefox/11.0|Mozilla/6.0 (Macintosh; I; Intel Mac OS X 11_7_9; de-LI; rv:1.9b4) Gecko/2012010317 Firefox/10.0a4|Mozilla/5.0 (Macintosh; I; Intel Mac OS X 11_7_9; de-LI; rv:1.9b4) Gecko/2012010317 Firefox/10.0a4|Mozilla/5.0 (X11; Mageia; Linux x86_64; rv:10.0.9) Gecko/20100101 Firefox/10.0.9|Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:9.0a2) Gecko/20111101 Firefox/9.0a2|Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:9.0) Gecko/20100101 Firefox/9.0|Mozilla/5.0 (Windows NT 5.1; rv:8.0; en_us) Gecko/20100101 Firefox/8.0';
$xua = explode('|',$ua);
$tua = count($xua);
$lidx = $tua-1;
$ridx = mt_rand(0,$lidx);
$theua = $xua[$ridx];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_USERAGENT, $theua);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_REFERER, $referer);
$hasil = curl_exec($ch);

$a = str_ireplace('<span class="st">','(.)',$hasil);
$b = str_ireplace('</span></div><div',').(',$a);
//$c = str_ireplace(array('<strong>','</strong>'),'',$b);
$c = explode('(.)',$b);
$i=1;
foreach($c as $e){
	if ($i < 1){
	}else{
		$f = explode(').(',$e);
		if (stripos($f[0],'http://') !== false || stripos($f[0],'https://') !== false){
			$f[0]='';
		}
		$data .= $f[0];
	}$i++;
}
$data = trim(str_ireplace(array('<em>','</em>','<wbr>','…','...','-'),'',$data));

//print_r($data);


$arrayWords = explode(' ', $data);

// Max size of each line
$maxLineLength = 750;

// Auxiliar counters, foreach will use them
$currentLength = 0;
$index = 0;

foreach($arrayWords as $word)
{
    // +1 because the word will receive back the space in the end that it loses in explode()
    $wordLength = strlen($word) + 1;

    if( ( $currentLength + $wordLength ) <= $maxLineLength )
    {
        $arrayOutput[$index] .= $word . ' ';

        $currentLength += $wordLength;
    }
    else
    {
        $index += 1;

        $currentLength = $wordLength;

        $arrayOutput[$index] = $word.'.';
    }
}

foreach ($arrayOutput as $output){
	$datas .= $output.'<p style="height:0.6em;"></p>';
}
	return $datas;
}

/** JS SPIN 2.0 -----------------------------------------------------
** Simple spinner
** Version 2.0 [2:36 PM 1/29/2013]
** Date: January 29, 2013
*/
function spinner($s){
  $s = explode("|", $s); shuffle($s); $s = $s[0]; return $s;
}
$tre='Contemporary |Minimalist |Traditional |Farmhouse |Craftsman |Modern |Beach Style |Transitional |Eclectic |Tropical |Rustic |Midcentury |Mediterranean |Asian |Industrial';
$tres = spinner($tre);

function decode($string){
	$string = str_ireplace('\u0021',"!",$string);
	$string = str_ireplace('\u0022','"',$string);
	$string = str_ireplace('\u0023',"#",$string);
	$string = str_ireplace('\u0024',"$",$string);
	$string = str_ireplace('\u0025',"%",$string);
	$string = str_ireplace('\u0026',"&",$string);
	$string = str_ireplace('\u0027',"'",$string);
	$string = str_ireplace('\u0028',"(",$string);
	$string = str_ireplace('\u0029',")",$string);
	$string = str_ireplace('\u002A',"*",$string);
	$string = str_ireplace('\u002B',"+",$string);
	$string = str_ireplace('\u002C',",",$string);
	$string = str_ireplace('\u002D',"-",$string);
	$string = str_ireplace('\u002E',".",$string);
	$string = str_ireplace('\u002F',"/",$string);
	
	
	return $string;
}

function scrap($keyword){
	$url='http://www.bing.com/images/search?q='.urlencode($keyword).'&qft=+filterui:photo-linedrawing+filterui:imagesize-medium';

$ua = 'Mozilla/6.0 (Windows NT 6.2; WOW64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1|Mozilla/5.0 (Windows NT 6.2; WOW64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1|Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1|Mozilla/5.0 (Windows NT 6.1; rv:15.0) Gecko/20120716 Firefox/15.0a2|Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.1.16) Gecko/20120427 Firefox/15.0a1|Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20120427 Firefox/15.0a1|Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:14.0) Gecko/20120405 Firefox/14.0a1|Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20120405 Firefox/14.0a1|Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20120405 Firefox/14.0a1|Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:14.0) Gecko/20100101 Firefox/14.0.1|Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:14.0) Gecko/20100101 Firefox/14.0.1|Mozilla/5.0 (Windows; U; Windows NT 6.1; WOW64; en-US; rv:2.0.4) Gecko/20120718 AskTbAVR-IDW/3.12.5.17700 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20120403211507 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/ 20120405 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.0; rv:14.0) Gecko/20100101 Firefox/14.0.1|Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (Windows NT 6.1; de;rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (compatible; Windows; U; Windows NT 6.2; WOW64; en-US; rv:12.0) Gecko/20120403211507 Firefox/12.0|Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.16) Gecko/20120421 Gecko Firefox/11.0|Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.16) Gecko/20120421 Firefox/11.0|Mozilla/5.0 (Windows NT 6.1; WOW64; rv:11.0) Gecko Firefox/11.0|Mozilla/5.0 (Windows NT 6.1; U;WOW64; de;rv:11.0) Gecko Firefox/11.0|Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko Firefox/11.0|Mozilla/6.0 (Macintosh; I; Intel Mac OS X 11_7_9; de-LI; rv:1.9b4) Gecko/2012010317 Firefox/10.0a4|Mozilla/5.0 (Macintosh; I; Intel Mac OS X 11_7_9; de-LI; rv:1.9b4) Gecko/2012010317 Firefox/10.0a4|Mozilla/5.0 (X11; Mageia; Linux x86_64; rv:10.0.9) Gecko/20100101 Firefox/10.0.9|Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:9.0a2) Gecko/20111101 Firefox/9.0a2|Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:9.0) Gecko/20100101 Firefox/9.0|Mozilla/5.0 (Windows NT 5.1; rv:8.0; en_us) Gecko/20100101 Firefox/8.0';
$xua = explode('|',$ua);
shuffle($xua); 
$theua = $xua[0];
$referer = 'http://www.google.com';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $theua);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_REFERER, $referer);

$hasil = curl_exec($ch);
curl_close($ch);

$a = preg_replace('/\s+/',' ',str_ireplace('<div class="lt">','[.]',str_ireplace('<div class="it">','[..]',str_ireplace('</div></a></div>','[...]',str_ireplace(array('<strong>','</strong>','</br>','<br/>','<br />'),' ',$hasil)))));
$b = explode('[.]',$a);
$i=1;
/* AMBIL KEYWORD SUGG DLL */
foreach ($b as $c){
	if(stripos($c,'header_smarttabs') !== false){
		$d = explode('[..]',$c);
		$ii = 0;
		foreach ($d as $e){
			if ($ii>0){
				$f = explode ('[...]',$e);
				$word = trim($f[0]);
				if (str_word_count($word)>1 && stripos($word,'.com') == false ){
					//$topSuggest .= $ii.'. '.build_permalink($word).' aslinya '.$word.'<br />';
					$arr_topSuggest[] = $word;
				}
			}
			$ii++;
		}
	}elseif(stripos($c,'header_entityplus') !== false || stripos($c,'header_rt') !== false){
		$d = explode('[..]',$c);
		$ii = 0;
		foreach ($d as $e){
			if ($ii>0){
				$f = explode ('[...]',$e);
				$word = trim($f[0]);
				if (str_word_count($word)>1 && stripos($word,'.com') == false ){
					//$relatedPost .= $ii.'. '.build_permalink($word).' aslinya '.$word.'<br />';
					$arr_relSuggest[] = $word;
				}
			}
			$ii++;
		}
	}elseif(stripos($c,'header_intentplus') !== false){
		$d = explode('[..]',$c);
		$ii = 0;
		foreach ($d as $e){
			if ($ii>0){
				$f = explode ('[...]',$e);
				$word = trim($f[0]);
				if (str_word_count($word)>1 && stripos($word,'.com') == false ){
					//$morePost .= $ii.'. '.build_permalink($word).' aslinya '.$word.'<br />';
					$arr_moreSuggest[] = $word;
				}
			}
			$ii++;
		}
	}elseif(stripos($c,'header_cluster') !== false){
		$d = explode('[..]',$c);
		$ii = 0;
		foreach ($d as $e){
			if ($ii>0){
				$f = explode ('[...]',$e);
				$word = trim($f[0]);
				if (str_word_count($word)>1 && stripos($word,'.com' ) == false){
					//$refinePost .= $ii.'. '.build_permalink($word).' aslinya '.$word.'<br />';
					$arr_refSuggest[] = $word;
				}
			}
			$ii++;
		}
	}
	$i++;
}

/* AMBIL GAMBAR */
$a = str_ireplace('<div class="dg_u"','[.]',$hasil);
//echo '<h1>Top suggest </h1>'.$topSuggest;
//echo '<h2>Related Post </h2>'.$relatedPost;
//echo '<h3>More Post </h3>'.$morePost;
//echo '<h4>Refine Post </h4>'.$refinePost.'<br />';

$b = explode('[.]',$a);
$arr_imgTitle = array();
/*$i=0;
foreach($b as $c){
	if($i>0){
		$imgTitle = explode ('t2=',$c);
		$imgTitle = explode ('t1=',$imgTitle[0]);
		$imgTitle = ucwords(preg_replace('/\s+/',' ',str_ireplace(array('+','-','jpg','gif','.','|'),' ',str_ireplace(array('=','"'),'',$imgTitle[1]))));
		//echo '<strong>TITLE IMAGE no '.$i.'</strong> : '.$imgTitle.'<br />';
		$imgSize = explode ('t3=',$c);
		$imgSize = explode ('t2=',$imgSize[0]);
		$imgSize = str_ireplace(array('=','"'),'',$imgSize[1]);
		$imgSize = explode ('·',$imgSize);
		//echo '&nbsp;&nbsp; Image Size : '.$imgSize[0].'<br />';
		//echo '&nbsp;&nbsp; File Size : '.$imgSize[1].'<br />';
		//echo '&nbsp;&nbsp; File Type : '.$imgSize[2].'<br />';
		$imgUrl = explode ('tid:',$c);
		$imgUrl = explode ('imgurl:',$imgUrl[0]);
		$imgUrl = str_ireplace(array('&quot;',','),'',$imgUrl[1]);
		//echo '&nbsp;&nbsp; Image Url asli: '.$imgUrl.'<br />';
		$thumbUrl = explode ('&amp;w=',$c);
		$thumbUrl = explode ('src2="',$thumbUrl[0]);
		//$thumbUrl = str_ireplace(array('&quot;',',',':'),'',$thumbUrl[1]);
		//echo '&nbsp;&nbsp; Image Url bing: '.$thumbUrl[1].'<br />';
		//echo '<a href="'.$imgUrl.'" target="_blank">Print This Image</a><br />';
		//echo '<a href="'.$imgUrl.'" download="'.$imgTitle.'.'.$imgSize[2].'" target="_blank">Download This Image</a>';
		//echo '<br />';
		$arr_imgTitle[] = array($imgTitle,$imgUrl,$thumbUrl[1],$imgSize[0],$imgSize[1],$imgSize[2]);
	}
	$i++;
}*/


		/* AMBIL GAMBAR */
	$hasil  = explode('<div id="mmComponent_images_1" class="dgControl hover" style="width:1014px" data-nextUrl="" data-postData="" data-iid="" data-layout="row">', $hasil);
	$hasila = explode('<div id="mmComponent_images_1_exp" class="expandButton disabled" data-expandOn=" scroll">', $hasil[1]);

	$content = preg_replace("/<\/?ul[^>]*\>/i", "", $hasila[0]);
	$content = preg_replace("/<\/?li[^>]*\>/i", "", $content);
	$content = preg_replace("/<\/?div[^>]*\>/i", "", $content);
	$content = preg_replace("/<\/?span[^>]*\>/i", "", $content);
	$content = preg_replace("/<\/?img[^>]*\>/i", "", $content);
	$content = str_ireplace( 'm="','<code>', $content );
	$content = str_ireplace( '" mad="','</code>(.Y.)', $content );
	$content = htmlspecialchars_decode($content);
	$con_ex  = explode('(.Y.)', $content);

	/* Image URL */
	$arr_imgTitle = array();
	$i            = 0;
	foreach ($con_ex as $co) {
		if($i > 0){
			$regex          = '#\<code>(.+?)\<\/code\>#s';
			preg_match($regex, $co, $matches);
			$get            = json_decode(str_replace(array('<code>','</code>'), '', $matches[0]));
			
			$ext            = pathinfo($get->purl, PATHINFO_EXTENSION);
			$imgTit         = str_replace('-',' ', trim(basename($get->purl, $ext), '.'));
			$imgTitle       = ucwords(preg_replace('/\s+/',' ', $imgTit));
			if (strpos($imgTitle, '?') !== false) {
				$imgTitle       = substr($imgTitle, 0, strpos($imgTitle, "?"));
			}
			
			$imgUrl         = $get->murl;
			
			$arr_imgTitle[] = array($imgTitle,$imgUrl);
		}
		$i++;
	}

	if (!empty($arr_imgTitle)) {
		$arr_imgTitle = array_map('array_filter', $arr_imgTitle);
		$arr_imgTitle = array_filter( $arr_imgTitle );
	}





$arr_scrap = array('top sugg' => $arr_topSuggest,'more sugg' => $arr_moreSuggest,'rel sugg' => $arr_relSuggest,'ref sugg' => $arr_refSuggest,'image' => $arr_imgTitle);
return $arr_scrap;
}

function ktw_nice_search() {
	$firstword = explode(' ',get_query_var('s'));
	if ( is_search() && strpos($_SERVER['REQUEST_URI'], '/wp-admin/') === false && strpos($_SERVER['REQUEST_URI'], '/'.strtolower($firstword[0]).'/') === false ) {
		wp_redirect(get_bloginfo('home') . '/'.strtolower($firstword[0]).'/' . str_replace(' ', '-', str_replace('%20', '-', strtolower(get_query_var('s')))));
		exit();
	}
}

add_action('template_redirect', 'ktw_nice_search');


function ktw_search_rule(){
    add_rewrite_rule('([^/]*)/([^/]*)?', 'index.php?s=$matches[1]', 'top');
}
add_action( 'init', 'ktw_search_rule' );

?>