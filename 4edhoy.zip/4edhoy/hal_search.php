<?php
if(stripos(urldecode($_SERVER['REQUEST_URI']),'/page/page-') !== false){
	$ktw_keywords=file(TEMPLATEPATH.'/qs.php');
	$jumlah_page = intval(count($ktw_keywords) / 1000);
	$ambil_db = false;
	//$ktw_keywords = explode('|',get_option('keywords'));
	$page = intval(str_ireplace('/page/page-','',$_SERVER['REQUEST_URI']));
	if($page > $jumlah_page){
		$ambil_db = true;
		$start_db = $jumlah_page + 1; 
	}
	if($ambil_db == true){
		if($page == $jumlah_page + 1){
			$db = $wpdb->get_results("SELECT `title` FROM `api` where id >= 1 and id <= 1000");
			shuffle($db);
			$i = 1;
			echo '<div class="cont"><ul id="tiga">';
			foreach($db as $keywords){
				$keywords = $keywords->title;
				if($i > 500){break;}else{
					$firstword = explode(' ',$keywords);
					echo '<li><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($keywords)).'">'.ucwords($keywords).'</a></li>';
				}
				$i++;
			}
		}else{
			$awal = (($page - $jumlah_page)- 1) * 1000 + 1;
			$akhir = ($page - $jumlah_page) * 1000;
			$db = $wpdb->get_results("SELECT `title` FROM `api` where id >= ".$awal." and id <= ".$akhir."");
			shuffle($db);
			$i = 1;
			echo '<div class="cont"><ul id="tiga">';
			foreach($db as $keywords){
				$keywords = $keywords->title;
				if($i > 500){break;}else{
					$firstword = explode(' ',$keywords);
					echo '<li><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($keywords)).'">'.ucwords($keywords).'</a></li>';
				}
				$i++;
			}
		}
	}else{
		if ($page == 1){
			for($a = 1;$a <= 1000;$a++){
				$ktw_key[] .= $ktw_keywords[$a];
			}
			
			shuffle($ktw_key);
			$i = 1;
			echo '<div class="cont"><ul id="tiga">';
			foreach($ktw_key as $keywords){
				if($i > 500){break;}else{
					$firstword = explode(' ',$keywords);
					echo '<li><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($keywords)).'">'.ucwords($keywords).'</a></li>';
				}
				$i++;
			}
		}else{
			$awal = ($page - 1) * 1000 + 1;
			$akhir = $page * 1000;
			for($a = $awal;$a <= $akhir;$a++){
				$ktw_key[] .= $ktw_keywords[$a];
			}
			shuffle($ktw_key);
			$i = 1;
			echo '<div class="cont"><ul id="tiga">';
			foreach($ktw_key as $keywords){
				if($i > 500){break;}else{
					$firstword = explode(' ',$keywords);
					echo '<li><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($keywords)).'">'.ucwords($keywords).'</a></li>';
				}
				$i++;
			}
		}
	}
	echo '</ul>';
	echo '<div class="paging">';
	/*page*/
	$jumlah_keywords = count($ktw_keywords);
	$jumlah_page = intval($jumlah_keywords / 1000);
	for ($a = 1;$a <= $jumlah_page;$a++){
		echo '<a href="'.$siteurl.'/page/page-'.$a.'">'.$a.' </a>';
	}
	$db = $wpdb->get_results("SELECT title FROM `api`");
	$jumlah_page_db = intval(count($db) / 1000);
	if($jumlah_page_db > 0){
		$total_page = $jumlah_page + $jumlah_page_db;
		for ($a = $jumlah_page;$a <= $total_page;$a++){
			echo '<a href="'.$siteurl.'/page/page-'.$a.'">'.$a.' </a>';
		}
	}
	echo '</div>';
	echo '</div>';
}else{
	if (!empty($topSugg)){
		foreach ($topSugg as $key){
			$words = explode(' ',strtolower($key));
			if (count($words)>4){
				$pecah = strlen($words[0]) + strlen($words[1]) + strlen($words[2]) + 2;
			}else{
				if (strlen($words[0])>= 10 || count($words) <= 2){
					$pecah = strlen($words[0]);
				}else{
					$pecah = strlen($words[0]) + strlen($words[1]) + 1;
					if ($pecah > 15){
						$pecah = strlen($words[0]);
					}
				}
			}
			$topSuggs .= '<div class="suggests"><a href="'.$siteurl.'/'.$words[0].'/'.sanitize_title_with_dashes(strtolower($key)).'">'.substr_replace($key,'<br />',intval($pecah),0).'</a></div>';
			$ktw_keywords[] .= $key;
		}
		if($b<=10){
			foreach ($topSugg as $key){
				$words = explode(' ',strtolower($key));
				$tag .= '<a style="margin:2px 2px;line-height: normal;" href="'.$siteurl.'/'.$words[0].'/'.sanitize_title_with_dashes(strtolower($key)).'" title="tagged with '.$key.'">#'.strtolower($key).'.</a>';
			}
		}
	}
	if (!empty($moreSugg)){
		foreach ($moreSugg as $key){
			$words = explode(' ',strtolower($key));
			if (count($words)>4){
				$pecah = strlen($words[0]) + strlen($words[1]) + strlen($words[2]) + 2;
			}else{
				if (strlen($words[0])>= 10 || count($words) <= 2){
					$pecah = strlen($words[0]);
				}else{
					$pecah = strlen($words[0]) + strlen($words[1]) + 1;
					if ($pecah > 15){
						$pecah = strlen($words[0]);
					}
				}
			}
			$moreSuggs .= '<div class="suggests"><a href="'.$siteurl.'/'.$words[0].'/'.sanitize_title_with_dashes(strtolower($key)).'">'.substr_replace($key,'<br />',intval($pecah),0).'</a></div>';
			$ktw_keywords[] .= $key;
		}
	}
	if (!empty($refSugg)){
		foreach ($refSugg as $key){
			$words = explode(' ',strtolower($key));
			if (count($words)>4){
				$pecah = strlen($words[0]) + strlen($words[1]) + strlen($words[2]) + 2;
			}else{
				if (strlen($words[0])>= 10 || count($words) <= 2){
					$pecah = strlen($words[0]);
				}else{
					$pecah = strlen($words[0]) + strlen($words[1]) + 1;
					if ($pecah > 15){
						$pecah = strlen($words[0]);
					}
				}
			}
			$refSuggs .= '<div class="suggests"><a href="'.$siteurl.'/'.$words[0].'/'.sanitize_title_with_dashes(strtolower($key)).'">'.substr_replace($key,'<br />',intval($pecah),0).'</a></div>';
			$ktw_keywords[] .= $key;
		}
	}
	if (!empty($relSugg)){
		foreach ($relSugg as $key){
			$words = explode(' ',strtolower($key));
			if (count($words)>4){
				$pecah = strlen($words[0]) + strlen($words[1]) + strlen($words[2]) + 2;
			}else{
				if (strlen($words[0])>= 10 || count($words) <= 2){
					$pecah = strlen($words[0]);
				}else{
					$pecah = strlen($words[0]) + strlen($words[1]) + 1;
					if ($pecah > 15){
						$pecah = strlen($words[0]);
					}
				}
			}
			$relSuggs .= '<div class="suggests"><a href="'.$siteurl.'/'.$words[0].'/'.sanitize_title_with_dashes(strtolower($key)).'">'.substr_replace($key,'<br />',intval($pecah),0).'</a></div>';
			$ktw_keywords[] .= $key;
		}
	}


	echo '<div class="single-title"><h1>'.ucwords($searchTitle).'</h1></div>';
	echo '<div class="posted"><span>Posted by '.$postedName.' in '.ucwords($category).'</span></div>';

	if (!empty($ads728)) {
		echo '<div class="ads">'.$ads728.'</div>';
	}

	if (!empty($hasilScrap['image'])){
		$images = $hasilScrap['image'];shuffle($images);
		$also = 'also|together with|as well|besides|in addition|additionally|furthermore|further|moreover|likewise';
		
		$x=0;
		$coun = count($images)-1;
		foreach ($images as $img){
			if($x<4){
				$alsospin = explode('|',$also);shuffle($alsospin);
				$imgTit = trim(str_ireplace(array('.',',','?','/','"',';',':','[',']','}','{','*','|','+','=','_','-',')','(','&','^','%','$','#','@','!','`','~','www','http','com','net','jpg','png','bmp','freshome','.us','.id','xyz','tk','pw','jpeg','amp','—'),' ',$img[0]));
				$altimg .= $imgTit.' '.$alsospin[0].' ';
			}elseif($x==4){
				$alsospin = explode('|',$also);shuffle($alsospin);
				$imgTit = trim(str_ireplace(array('.',',','?','/','"',';',':','[',']','}','{','*','|','+','=','_','-',')','(','&','^','%','$','#','@','!','`','~','www','http','com','net','jpg','png','bmp','freshome','.us','.id','xyz','tk','pw','jpeg','amp','—'),' ',$img[0]));
				$altimg .= $imgTit.'.';
			}
			$x++;
		}
	/*Image Slider*/		
		echo '<div class="csslider1 autoplay">';
		$i=0;
		foreach ($images as $img){
			echo'<input name="cs_anchor1" id="cs_slide1_'.$i.'" type="radio" class="cs_anchor slide">';
			$i++;
		}
		echo'<input name="cs_anchor1" id="cs_play1" type="radio" class="cs_anchor" checked="">';
		$i=0;
		foreach ($images as $img){
			echo'<input name="cs_anchor1" id="cs_pause1_'.$i.'" type="radio" class="cs_anchor pause">';
			$i++;
		}

		echo'<ul>';
			
		$a=0;	
		foreach($images as $img){
			$imgTit = trim(str_ireplace(array('.',',','?','/','"',';',':','[',']','}','{','*','|','+','=','_','-',')','(','&','^','%','$','#','@','!','`','~','www','http','com','net','jpg','png','bmp','freshome','.us','.id','xyz','tk','pw','jpeg','amp','—'),' ',$img[0]));
			$imgUrl = $img[1];
			if($a==0){
				echo '<li class="cs_skeleton"><img src="'.$imgUrl.'" style="width: 100%;">'.
					'</li>'.
					'<li class="num'.$a.' img slide">'.
					 '<a href="'.$imgUrl.'" class="k" rel="nofollow"><img width="780" height="460" src="'.$imgUrl.'" alt="'.$altimg.' on '.$searchTitle.'" title="'.ucwords(strtolower($imgTit)).'" onError="this.onerror=null;this.src=\''.$img[2].'\';"/></a>'.
					'</li>';
			}else{
				echo '<li class="num'.$a.' img slide">'.
					'<a href="'.$imgUrl.'" class="k" rel="nofollow"><img width="780" height="460" src="'.$imgUrl.'" alt="'.$altimg.' on '.$searchTitle.'" title="'.ucwords(strtolower($imgTit)).'" onError="this.onerror=null;this.src=\''.$img[2].'\';"/></a>'.
				'</li>';
			}$a++;
		}
		
		echo'</ul>'.
		'<div class="cs_description">';
		$i=0;
		foreach ($images as $img){
			$imgTit = trim(str_ireplace(array('.',',','?','/','"',';',':','[',']','}','{','*','|','+','=','_','-',')','(','&','^','%','$','#','@','!','`','~','www','http','com','net','jpg','png','bmp','freshome','.us','.id','xyz','tk','pw','jpeg','amp','—'),' ',$img[0]));
			$firstword = explode(' ',$imgTit);
			echo'<label class="num'.$i.'">'.
			'<span class="cs_title"><span class="cs_wrapper"><h3><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower(trim($imgTit))).'" target="_blank">'.ucwords(strtolower(trim($imgTit))).'</a></h3></span></span>'.
			'</label>';
			$i++;
		}
		echo'</div>';
		echo'<div class="cs_play_pause">';
		$i=0;
		foreach ($images as $img){
			if($i==1){
				echo'<label class="cs_play" for="cs_play1"><span><i></i><b></b></span></label>'.
				'<label class="cs_pause num0" for="cs_pause1_'.$i.'"><span><i></i><b></b></span></label>';
			}else{
				echo'<label class="cs_pause num1" for="cs_pause1_'.$i.'"><span><i></i><b></b></span></label>';
			}
			$i++;
		}
		echo'</div>';
		echo'<div class="cs_arrowprev">';
		$i=0;
		foreach($images as $img){
			echo'<label class="num'.$i.'" for="cs_slide1_'.$i.'"><span><i></i><b></b></span></label>';
			$i++;
		}	
		echo'</div>';
		
		echo'<div class="cs_arrownext">';
		$i=0;
		foreach($images as $img){
			echo'<label class="num'.$i.'" for="cs_slide1_'.$i.'"><span><i></i><b></b></span></label>';
			$i++;
		}		
		echo'</div>';
		echo'<div class="cs_bullets">';
		$i=0;
		foreach ($images as $img){
			$imgTit = trim(str_ireplace(array('.',',','?','/','"',';',':','[',']','}','{','*','|','+','=','_','-',')','(','&','^','%','$','#','@','!','`','~','www','http','com','net','jpg','png','bmp','freshome','.us','.id','xyz','tk','pw','jpeg','amp','—'),' ',$img[0]));
			$imgUrl = $img[1];

		echo'<label class="num'.$i.'" for="cs_slide1_'.$i.'">'.
				'<span class="cs_point"></span>'.
				'<span class="cs_thumb"><img src="'.$imgUrl.'" alt="'.$imgTit.' on '.$searchTitle.'" title="'.ucwords(strtolower($imgTit)).'" onError="this.onerror=null;this.src=\''.$img[2].'\';"/></span>'.
			'</label>';
		$i++;
	}
		echo'</div>';
	echo '</div>';

	}
	echo '<div class="tag">Tagged with : '.$tag.'</div>';
	echo '<div style="font-size:10px;padding:0 10px 10px;border-bottom:2px groove #7686AB"><u>Disclaimer:</u> We don’t host ANY of these image files. We never store the image file in our host. We just links to many other sites out there. If you need to remove any file, please contact original image uploader.</div>'; 


	echo '<div class="single-content">';
	//echo '<h2>People who looking for <i>'.$searchTitle.'</i> also like :</h2>';
	if (!empty($ads728)) {
		echo '<div class="ads">'.$ads728.'</div>';
	}
	if (!empty($moreSugg)){
		echo '<h2 style="margin: 15px 10px; font-weight: bold;font-size: 17px;">More keywords like <u>'.ucwords($searchTitle).'</u> other people like : </h2>';
		echo '<div class="sugg-cont">'.$moreSuggs.'</div>';
	}elseif(!empty($refSugg) && $ygsudah !== 'ref'){
		echo '<h2 style="margin: 15px 10px; font-weight: bold;font-size: 17px;">Related keywords to <u>'.ucwords($searchTitle).'</u> : </h2>';
		echo '<div class="sugg-cont">'.$refSuggs.'</div>';
		$ygsudah = 'ref';
	}elseif(!empty($relSugg) && $ygsudah !== 'rel'){
		echo '<h2 style="margin: 15px 10px; font-weight: bold;font-size: 17px;">Maybe this keywords is what u looking : </h2>';
		echo '<div class="sugg-cont">'.$relSuggs.'</div>';
		$ygsudah = 'rel';
	}
	echo'<h2>'.ucwords($searchTitle).' Description</h2>';

	$ktw_jumlah = count($images);
	$a_spin = array('Today we have','Today we bring you','Now we give you','Right now we have');shuffle($a_spin);
	$b_spin = array('that provides along','that offers along','that offers with','that brings alongside');shuffle($b_spin);
	$also_spin = array('as well as','together with','also with','additionally','moreover','furthermore','including','along with');shuffle($also_spin);
	$i=1;
	foreach($images as $data){
		
		if($i == 1){
			echo '<p>'.$a_spin[0].' '.$searchTitle.' '.$b_spin[0].' '.$ktw_jumlah.' pictures '.$also_spin[0].' ';
			$k = 1;
			foreach($ktw_keywords as $keyword){
				if($k == 11){break;}else{
					if($k < 10){
						shuffle($also_spin);
						echo $keyword.' '.$also_spin[0].' ';
					}else{
						echo $keyword.'.</p>';
					}
				}$k++;
			}
			echo '<br>';
		}elseif($i==2){
			shuffle($also_spin);
			echo '<p>'.strtolower($data[0]).' '.$also_spin[0].' ';
		}elseif($i==10 || $i==$ktw_jumlah){
			shuffle($also_spin);
			echo strtolower($data[0]).'</p>';
		}else{
			shuffle($also_spin);
			echo strtolower($data[0]).' '.$also_spin[0].' ';
		}
		$i++;	
	}

	if (!empty($ads728)) {
		echo '<div class="ads">'.$ads728.'</div>';
	}

	if(!empty($refSugg) && $ygsudah !== 'ref'){
		echo '<h2 style="margin: 15px 10px; font-weight: bold;font-size: 17px;">Related keywords to <u>'.ucwords($searchTitle).'</u> : </h2>';
		echo '<div class="sugg-cont">'.$refSuggs.'</div>';
		$ygsudah = 'ref';
	}elseif(!empty($relSugg) && $ygsudah !== 'rel'){
		echo '<h2 style="margin: 15px 10px; font-weight: bold;font-size: 17px;">Maybe this keywords is what u looking : </h2>';
		echo '<div class="sugg-cont">'.$relSuggs.'</div>';
		$ygsudah = 'rel';
	}
	echo '</div>';
	/* $title=''.$data.' - '.strtolower($ttt).' '.$sitename.'';
	$robots = '<meta name="robots" content="index,follow"/>';
	$md='<meta name="description" content="'.$mdsr.' '.$data.'"/>';
	$mk='<meta name="keywords" content="'.$nadif.$data.'"/>';
	$ogmd='<meta property="og:site_name" content="'.$siteurl.'" />'.
	'<meta property="og:description" content="'.$mdsr.' '.$data.'" />'.
	'<meta property="og:type" content="website" />'.
	'<meta property="og:image" content="'.$tsek[1].'" />';
	 */
}


?>