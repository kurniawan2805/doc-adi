<?php
/* $keyurl='http://www.ktwadd.xyz/license.php';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $keyurl);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/6.0 (Windows NT 6.2; WOW64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

$hasil = curl_exec($ch);
curl_close($ch); */

//if (isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/bot|crawl|slurp|spider/i', $_SERVER['HTTP_USER_AGENT'])) {
  
//if($key == $hasil){
if(strpos(urldecode($_SERVER['REQUEST_URI']),'sitemap.xml')){ include "sitemap-gen.php"; } else {
if(is_search()){	
	$dataUrl = urldecode($_SERVER['REQUEST_URI']);
	$dataUrl1 = explode('/',$dataUrl);
	$dfirstWord = $dataUrl1[1];
	$searchTitle = str_replace('-',' ',basename($dataUrl));
	$firstWord = explode(' ',$searchTitle);

	$badWord = badWords($searchTitle);
	$subs = explode(' ',$searchTitle);
	if(!empty($subs)){
		$newWord = implode(' ',array_unique($subs));
	}
	if($dfirstWord !== $firstWord[0] || str_word_count($searchTitle)>10 || $badWord !== 'tidak ada' || $newWord !== $searchTitle){
		$filtered = $searchTitle;
		if ($badWord == 'tidak ada'){}{
			for ($i=1; $i<=str_word_count($filtered); $i++){ //buang bad word
			$badWord = badWords($searchTitle);
			$filtered = str_ireplace($badWord,'',$filtered);
			}
		}
		$a = 1;
		$firstWords = explode(' ',$filtered);
		foreach($firstWords as $word){
			if($a >= 10){break;}else{
			$sub .= strtolower($word).' ';
			$a++;
			}
		}
		$subs = explode(' ',$sub);
		if(!empty($subs)){
			$newWord = implode(' ',array_unique($subs));
		}else{
			$newWord = implode(' ',array_unique($firstWords));
		}
		Header("Location: ".$siteurl."/".$firstWords[0]."/".sanitize_title_with_dashes($newWord), true, 301); exit;
	} 
}elseif(is_page()){
	
}elseif(is_archieve){	
	$dataUrl = urldecode($_SERVER['REQUEST_URI']);
	$dataUrl1 = explode('/',$dataUrl);
	$dfirstWord = $dataUrl1[0];
	$searchTitle = str_replace('-',' ',basename($dataUrl));
	$firstWord = explode(' ',$searchTitle);

	$badWord = badWords($searchTitle);
	$subs = explode(' ',$searchTitle);
	if(!empty($subs)){
		$newWord = implode(' ',array_unique($subs));
	}
	if($dfirstWord !== $firstWord[0] || str_word_count($searchTitle)>10 || $badWord !== 'tidak ada' || $newWord !== $searchTitle){
		$filtered = $searchTitle;
		if ($badWord == 'tidak ada'){}{
			for ($i=1; $i<=str_word_count($filtered); $i++){ //buang bad word
			$badWord = badWords($searchTitle);
			$filtered = str_ireplace($badWord,'',$filtered);
			}
		}
		$a = 1;
		$firstWords = explode(' ',$filtered);
		foreach($firstWords as $word){
			if($a >= 10){break;}else{
			$sub .= strtolower($word).' ';
			$a++;
			}
		}
		$subs = explode(' ',$sub);
		if(!empty($subs)){
			$newWord = implode(' ',array_unique($subs));
		}else{
			$newWord = implode(' ',array_unique($firstWords));
		}
		Header("Location: ".$siteurl."/".$firstWords[0]."/".sanitize_title_with_dashes($newWord), true, 301); exit;
	} 
}

echo'<!DOCTYPE html>';
echo'<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xmlns:x2="http://www.w3.org/2002/06/xhtml2" xmlns:fb="http://www.facebook.com/2008/fbml"  itemscope itemtype="http://schema.org/Article" itemid="http://'.$_SERVER[HTTP_HOST].$_SERVER[REQUEST_URI].'">';
if(is_search()){$h='h2';} else {$h='h1';}
echo'<head>';
echo $gmeta.$bmeta.$ameta;
$breadcrumb='Welcome to '.$sitename.' '.$sitedesc.'';
$robots='<meta name="robots" content="index,follow"/>';
$readySql = true;
if(is_home()){
	$getdbHome = $wpdb->get_results("SELECT * FROM `api` order by id DESC limit 200");shuffle($getdbHome);	
	if (!empty($getdbHome)){
		$hasilScrap = scrap($main_keyword);
		$breadcrumb='Welcome to '.$sitename;
		$title=$sitename.' - '.$sitedesc;
		$robots = '<meta name="robots" content="index,follow"/>';
		$metaDescription='<meta name="description" content="'.$home_description.'"/>';
		$metaKeyword='<meta name="keywords" content="'.$home_keywords.'"/>';
		foreach ($getdbHome as $homeDb){
			$titHome = $homeDb->title;
			$datHome = $homeDb->data;
			$sqldatas = explode('[.Y.]',$datHome);shuffle($sqldatas);
			$sqldata = explode('(.|.)',$sqldatas[0]);
			$imgTitle = $sqldata[0];
			$imgUrl = $sqldata[1];
			$og .= '<meta property="og:image" content="'.$imgUrl.'" />';
		}
		$ogmd='<meta property="og:site_name" content="'.$siteurl.'" />'.
		'<meta property="og:description" content="'.$home_description.'"/>'.
		'<meta property="og:type" content="website" />'.$og;
		
		
	}else{
		$hasilScrap = scrap($main_keyword);
		$images = $hasilScrap['image'];
		$breadcrumb='Welcome to '.$sitename;
		$title=$sitename.' - '.$sitedesc;
		$robots = '<meta name="robots" content="index,follow"/>';
		$metaDescription='<meta name="description" content="'.$home_description.'"/>';
		$metaKeyword='<meta name="keywords" content="'.$home_keywords.'"/>';
		foreach ($hasilScrap['image'] as $img){
			$og .= '<meta property="og:image" content="'.$img[1].'" />';
		}
		$ogmd='<meta property="og:site_name" content="'.$siteurl.'" />'.
		'<meta property="og:description" content="'.$home_description.'"/>'.
		'<meta property="og:type" content="website" />'.$og;
	}
}elseif(is_search()){
	
	$dataUrl = urldecode($_SERVER['REQUEST_URI']);
	$searchTitle = str_replace('-',' ',basename($dataUrl));
	$category = explode(' ',$searchTitle); $category = $category[0];
	$badWord = badWords($searchTitle);
	$whiteWord = whiteWords($searchTitle);
	
	if ($whiteWord == 'ada' && $badWord == 'tidak ada'){
		if(str_word_count($searchTitle) < 3) {
			$robots = '<meta name="robots" content="noindex,follow"/>'; 
			$readySql = false;
		}/*noindex jika short tail keyword*/
	}else{
		$readySql = false;
		for ($i=1; $i<=str_word_count($searchTitle); $i++){ //buang bad word
			$badWord = badWords($searchTitle);
			$searchTitle = str_ireplace($badWord,'',$searchTitle);
		}
		if(str_word_count($searchTitle) < 2 || $whiteWord !== 'ada') {
			$robots = '<meta name="robots" content="noindex,follow"/>'; 
			$readySql = false;
		}/*noindex jika short tail keyword*/else{
			
		}
	}
	
	$hasilScrap = scrap($searchTitle);
	if (!empty($hasilScrap['image'])){
		$images = $hasilScrap['image'];shuffle($images);
	}
	if (!empty($hasilScrap['top sugg'])){
		$topSugg = $hasilScrap['top sugg'];shuffle($topSugg);
		foreach ($topSugg as $key){
			$meta_top .= $key.',';
		}
	}
	if (!empty($hasilScrap['more sugg'])){
		$moreSugg = $hasilScrap['more sugg'];shuffle($moreSugg);
		foreach ($moreSugg as $key){
			$meta_more .= $key.',';
		}
	}
	if (!empty($hasilScrap['ref sugg'])){
		$refSugg = $hasilScrap['ref sugg'];shuffle($refSugg);
		foreach ($refSugg as $key){
			$meta_ref .= $key.',';
		}
	}
	if (!empty($hasilScrap['rel sugg'])){
		$relSugg = $hasilScrap['rel sugg'];shuffle($relSugg);
		foreach ($relSugg as $key){
			$meta_rel .= $key.',';
		}
	}
	$jumlah = count($images);
	
	/* Block Suggest Keyword */
	$suggest = suggKeyword($searchTitle);
	if (!empty($suggest)){
		shuffle($suggest);
		$i=0;
		$b=count($suggest); 
		
		foreach($suggest as $tagged){
			$firstword = explode(' ',$tagged);
			if ($firstword[0] !== '' && $tagged !== $searchTitle && $i < $b){
				$tag .= '<a style="margin:2px 2px;line-height: normal;" href="'.$siteurl.'/'.$firstword[0].'/'.sanitize_title_with_dashes(strtolower($tagged)).'" title="tagged with '.$tagged.'">#'.strtolower($tagged).', </a>';
			}elseif ($i==$b){
				$tag .= '<a style="margin:2px 2px;line-height: normal;" href="'.$siteurl.'/'.$firstword[0].'/'.sanitize_title_with_dashes(strtolower($tagged)).'" title="tagged with '.$tagged.'">#'.strtolower($tagged).'.</a>';
			}elseif ($tagged == $searchTitle){
				$i=$i+1;
			}
			$i++;
		}
	}else{
	
	}
	
	
	$metaKeyword = $meta_top.$meta_more.$meta_ref.$meta_rel;
	
	$a = 1;
	if (!empty($images)) {
		$images = $images;
	}else {
		$images = array();
	}
	foreach ($images as $img){
		if ($a==5){break;}
		if ($a == $jumlah || $a==4){
			$imgTit = trim(str_ireplace(array('.',',','?','/','"',';',':','[',']','}','{','*','|','+','=','_','-',')','(','&','^','%','$','#','@','!','`','~','www','http','com','net','jpg','png','bmp','freshome','.us','.id','xyz','tk','pw','jpeg','amp','—'),' ',$img[0]));
			$alsoSpin = Spinner('also|together with|along with|in addition|as well as|moreover|furthermore|further');
			$metaDesc .= trim(strtolower($imgTit)).'.';
			$dbImg .= trim($img[0]).'(.Y.)'.trim($img[1]).'(.Y.)'.trim($img[2]).'(.Y.)'.trim($img[3]).'(.Y.)'.trim($img[4]).'(.Y.)'.trim($img[5]);
		}else{
			$imgTit = trim(str_ireplace(array('.',',','?','/','"',';',':','[',']','}','{','*','|','+','=','_','-',')','(','&','^','%','$','#','@','!','`','~','www','http','com','net','jpg','png','bmp','freshome','.us','.id','xyz','tk','pw','jpeg','amp','—'),' ',$img[0]));
			$alsoSpin = Spinner('also|together with|along with|in addition|as well as|moreover|furthermore|further');
			$metaDesc .= trim(strtolower($imgTit)).' '.$alsoSpin.' ';
			$dbImg .= trim($img[0]).'(.Y.)'.trim($img[1]).'(.Y.)'.trim($img[2]).'(.Y.)'.trim($img[3]).'(.Y.)'.trim($img[4]).'(.Y.)'.trim($img[5]).'[.Y.]';
		}
		$a++;
	}
	
	$checkData = $wpdb->get_results("SELECT * FROM `api` WHERE title = '".$searchTitle."'");
	if (empty($checkData)){		
		/*INSERT DB*/
	if (str_word_count($searchTitle) > 2){ 
		if ($readySql !== false){
			if (empty($checkData) && trim($dbImg) !== ''){
				$today = date('Y-m-d h:i:s'); 
				$plusday = mt_rand(-5,-1);
				$plushour = mt_rand(1,24); 
				$plusmin = mt_rand(1,59); 
				$plussec = mt_rand(1,59); 
				$date = date('Y-m-d h:i:s', strtotime('+'.$plusday.' day +'.$plushour.' hour +'.$plusmin.' minutes +'.$plussec.' seconds',''.strtotime($today).''));
				$query = "INSERT INTO api values('','".ucwords($searchTitle)."','".$dbImg."','".$date."')";
				$wpdb->query($query);
				
			}
		}
	}
	}else{
		
	}
	
	$breadcrumb = '<a href = "'.$siteurl.'">Home</a> >> '.ucwords($category).' >> <a href = "#">'.ucwords($searchTitle).'</a>';
	
	$title = ucwords(strtolower($searchTitle).'. '.$category.'. '.$sitedesc);
	$metaDescription = '<meta name="description" content="'.ucfirst(strtolower($searchTitle)).' '.$alsoSpin.' '.$metaDesc.'"/>';
	$metaKeyword = '<meta name="keywords" content="'.strtolower(trim($metaKeyword).$searchTitle).'"/>';
	
	foreach ($images as $img){
		$og.='<meta property="og:image" content="'.$img[1].'" />';
	}
	$ogmd = '<meta property="og:site_name" content="'.$siteurl.$dataUrl.'.html" />'.
			'<meta property="og:description" content="'.ucfirst(strtolower($searchTitle)).' '.$alsoSpin.' '.$metaDesc.'"/>'.
			'<meta property="og:type" content="website" />'.
			$og;
	
	if(stripos(urldecode($_SERVER['REQUEST_URI']),'/page/page-') !== false){
		$title = ucwords($searchTitle.' | '.$sitedesc.' on '.$sitename);
		$robots = '<meta name="robots" content="noindex,follow"/>';
		$metaDescription = '<meta name="description" content="'.$home_description.'"/>';
		$metaKeyword = '<meta name="keywords" content="'.$home_keywords.'"/>';
		$ogmd = '';
	}
}elseif(is_page()){
	$dataUrl = urldecode($_SERVER['REQUEST_URI']);
	$title = ucwords(strtolower(str_ireplace('/','',$dataUrl))).' | '.$sitedesc.' on '.$sitename;
	$robots = '<meta name="robots" content="noindex,nofollow"/>';
}elseif(is_archieve){
	$dataUrl = urldecode($_SERVER['REQUEST_URI']);
	$title = 'Archieve for '.ucwords(strtolower(str_ireplace('/','',$dataUrl))).' | '.$sitedesc.' on '.$sitename;
	$robots = '<meta name="robots" content="noindex,nofollow"/>';
}

echo $meta_verif.$iklan_revhits;
echo'<title>'.$title.'</title>';
echo $robots.$metaDescription.$metaKeyword.$ogmd;
echo'<meta charset="UTF-8" /><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">';
echo'<link rel="stylesheet" type="text/css" media="all" href="'.$themeurl.'/style.css"/>';
echo'<link rel="stylesheet" type="text/css" media="all" href="'.$themeurl.'/stylea.css"/>';
echo'<meta name="viewport" content="width=device-width, initial-scale=1.0" />';
echo'<script type="text/javascript" src="'.$themeurl.'/js/j.js"></script>'; 
echo'<script type="text/javascript" src="'.$themeurl.'/js/z.js"></script>'; 
echo'<!--[if IE]><link rel="stylesheet" href=""'.$themeurl.'/ie.css"><![endif]--><!--[if lte IE 9]><script type="text/javascript" src=""'.$themeurl.'/js/ie.js"></script><![endif]-->';
echo'<script type="text/javascript">';
echo'$(function(){$.fn.fancyzoom.defaultsOptions.imgDir="'.$themeurl.'/images/z/";$(".k").fancyzoom({Speed:400,showoverlay:false});});';
echo'</script>';
echo'</head>';
echo'<body id="blog" itemscope itemtype="http://schema.org/WebPage">';

/*HEADER*/
echo'<div class="header-cont">';
echo'<div class="header">'.
	'<div class="header-title"><'.$h.'><a href="'.$siteurl.'">'.$sitename.'</a></'.$h.'></div>'.
	'<div class="header-ads">'.
		'<form id="search" role="search" method="get" class="input-group" action="'.$siteurl.'"><input type="search" class="form-control full" placeholder="Search Here" value="" name="s" title="Search for:"></form>'.
	'</div>'.
	'</div>';
echo'</div>';
//echo'<div class="breadcrumb">'.$breadcrumb.'</div>';
echo'<div class="content">';

if (is_home()){
//print_r (scrap('math worksheets')['image']);
require_once("hal_home.php");

}elseif(is_search()){
	
require_once("hal_search.php");

}elseif(is_page()) {

require_once("hal_sitemap.php");

}elseif(is_archive()){

require_once("hal_archieve.php");

}else{

}

/*FOOTER*/

$args = array('sort_column' => 'post_title','post_type' => 'page','post_status' => 'publish');
$pages = get_pages($args); 
echo'<div class="footer">';
echo "Copyright &copy ".date('Y')." <a href=\"".$siteurl."\">".$sitename."</a>";
echo '<div style="float:right">';
	echo '<div class="foot-cont"><a href="'.$siteurl.'/about-us" title="Contact Us" rel="nofollow">About Us</a></div>';
	echo '<div class="foot-cont"><a href="'.$siteurl.'/contact-us" title="Contact Us" rel="nofollow">Contact Us</a></div>';
	echo '<div class="foot-cont"><a href="'.$siteurl.'/privacy-policy" title="Privacy Policy" rel="nofollow">Privacy Policy</a></div>';
	echo '<div class="foot-cont"><a href="'.$siteurl.'/dmca" title="Disclaimer" rel="nofollow">DMCA</a></div>';
	echo '<div class="foot-cont"><a href="'.$siteurl.'/disclaimer" title="Disclaimer" rel="nofollow">Disclaimer</a></div>';
echo '</div>';

echo '<div class="sitemap">Sitemap Index : ';
foreach ($pages as $page){
	$url = $page->guid;
	$title = $page->post_title;
	if (stripos($title,'disclaimer') !==false
		|| stripos($title,'contact us') !==false
		|| stripos($title,'privacy policy') !==false
		|| stripos($title,'about us') !==false
		|| stripos($title,'dmca') !==false
		|| $title == 'Sitemap'
	){
		
	}else{
		$title = str_ireplace('sitemap ','',$title);
		echo '<a href="'.$siteurl.'/sitemap-'.$title.'">'.$title.'</a>';
		echo ' ';
	}
}
echo'</div>';
echo' </div>';
echo $code_histats;
echo'</body>';

echo'<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-56e88f5e47817826"></script>';

echo '</html>';

}

//}
   /*penutup sitemap*/
/* }else{
	Header("Location: //hlok.qertewrt.com/offer?prod=141&ref=5045941", true, 301); exit;
} */
?>