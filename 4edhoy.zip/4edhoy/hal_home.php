<?php
$ktw_keywords=file(TEMPLATEPATH.'/qs.php');
//$ktw_keywords = explode('|',get_option('keywords'));
if(!empty($ktw_keywords)){
	shuffle($ktw_keywords);
	$i = 1;
	echo '<div class="cont"><ul id="tiga">';
	foreach($ktw_keywords as $keywords){
		if($i > 1000){break;}else{
			$firstword = explode(' ',$keywords);
			echo '<li><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($keywords)).'">'.ucwords($keywords).'</a></li>';
		}
		$i++;
	}
	if(!empty($getdbHome)){
		shuffle($getdbHome);
		$i = 1;
		foreach ($getdbHome as $homeDb){
			$titHome = $homeDb->title;
			if($i > 100){break;}else{
				$firstword = explode(' ',$titHome);
				echo '<li><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($titHome)).'">'.ucwords($titHome).'</a></li>';
			}
			$i++;
		}
	}
	
	echo '</ul>';
	echo '<div class="paging">';
	/*page*/
	$jumlah_keywords = count($ktw_keywords);
	$jumlah_page = intval($jumlah_keywords / 1000);
	for ($a = 1;$a <= $jumlah_page;$a++){
		echo '<a href="'.$siteurl.'/page/page-'.$a.'">'.$a.' </a>';
	}
	$db = $wpdb->get_results("SELECT title FROM `api`");
	$jumlah_page_db = intval(count($db) / 1000);
	if($jumlah_page_db > 0){
		$total_page = $jumlah_page + $jumlah_page_db;
		for ($a = $jumlah_page;$a <= $total_page;$a++){
			echo '<a href="'.$siteurl.'/page/page-'.$a.'">'.$a.' </a>';
		}
	}
	echo '</div>';
	echo '</div>';
	
}else{
if (!empty($hasilScrap['image'])){
	$images = $hasilScrap['image'];shuffle($images);
}
if (!empty($hasilScrap['top sugg'])){
	$topSugg = $hasilScrap['image'];shuffle($topSugg);
}
if (!empty($hasilScrap['more sugg'])){
	$moreSugg = $hasilScrap['image'];shuffle($moreSugg);
}
if (!empty($hasilScrap['rel sugg'])){
	$relSugg = $hasilScrap['image'];shuffle($relSugg);
}
if (!empty($hasilScrap['ref sugg'])){
	$refSugg = $hasilScrap['image'];shuffle($refSugg);
}

	//<div class="ads"></div>';
	if(!empty($getdbHome)){
echo'<div class="home-galery">';
		$pic = 1;
		$ads = 1;
		$jumlah = count($getdbHome);
		shuffle($getdbHome);
		foreach ($getdbHome as $homeDb){
			$titHome = $homeDb->title;
			$datHome = $homeDb->data;
			$sqldata = explode('[.Y.]',$datHome);shuffle($sqldata);
			$sqldata = explode('(.Y.)',$sqldata[0]);
			$imgTitle = $sqldata[0];
			$imgTitle = trim(str_ireplace(array('.',',','?','/','"',';',':','[',']','}','{','*','|','+','=','_','-',')','(','&','^','%','$','#','@','!','`','~','www','http','com','net','jpg','png','bmp','freshome','.us','.id','xyz','tk','pw','jpeg'),' ',$imgTitle));
			$imgUrl = $sqldata[1];
			$altimgUrl = $sqldata[2];
			$firstwordd = explode(' ',$titHome);
			$firstword = explode(' ',$imgTitle);
			if (count($firstword) < 2){
				$imgTitle = $titHome;
			}
		
		if ($pic %3 == 1){
			if ($pic == 1 || $pic == 7){echo '<div class="ads">'.$ads728.'</div>';}else{}
			echo'<div class="li-cont">';
			echo'<li><a href="'.$imgUrl.'" rel="nofollow" class="k" ><img height="300" width="300" src="'.$imgUrl.'" alt="'.$imgTitle.' on '.$titHome.'" title="'.ucwords(strtolower($imgTitle)).'" onError="this.onerror=null;this.src=\''.$altimgUrl.'\';"/></a>
			<div class="home-img-title"><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($imgTitle)).'">'.ucwords(strtolower($imgTitle)).'</a></div>
			<div class="home-img-tag">Posted on <a href="'.$siteurl.'/'.strtolower($firstwordd[0]).'/'.sanitize_title_with_dashes(strtolower($titHome)).'">'.ucwords($titHome).'</a> by '.spinner($Name).'</div>
			</li>';
		}elseif ($pic %3 == 0 || $pic == $jumlah){
			echo'<li><a href="'.$imgUrl.'" rel="nofollow" class="k" ><img height="300" width="300" src="'.$imgUrl.'" alt="'.$imgTitle.' on '.$titHome.'" title="'.ucwords(strtolower($imgTitle)).'" onError="this.onerror=null;this.src=\''.$altimgUrl.'\';"/></a>
			<div class="home-img-title"><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($imgTitle)).'">'.ucwords(strtolower($imgTitle)).'</a></div>
			<div class="home-img-tag">Posted on <a href="'.$siteurl.'/'.strtolower($firstwordd[0]).'/'.sanitize_title_with_dashes(strtolower($titHome)).'">'.ucwords($titHome).'</a> by '.spinner($Name).'</div>
			</li>';
			echo'</div>';
		}else{
			echo'<li><a href="'.$imgUrl.'" rel="nofollow" class="k" ><img height="300" width="300" src="'.$imgUrl.'" alt="'.$imgTitle.' on '.$titHome.'" title="'.ucwords(strtolower($imgTitle)).'" onError="this.onerror=null;this.src=\''.$altimgUrl.'\';"/></a>
			<div class="home-img-title"><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($imgTitle)).'">'.ucwords(strtolower($imgTitle)).'</a></div>
			<div class="home-img-tag">Posted on <a href="'.$siteurl.'/'.strtolower($firstwordd[0]).'/'.sanitize_title_with_dashes(strtolower($titHome)).'">'.ucwords($titHome).'</a> by '.spinner($Name).'</div>
			</li>';
		}$pic++;$ads++;
		}
echo'</div>';
	}else{
		echo'<div class="home-galery">';
		
		$pic = 1;
		$ads = 1;
		$jumlah = count($images);
		foreach ($images as $img){
			$titHome = $main_keyword;
			$imgTitle = $img[0];
			$imgUrl = $img[1];
			$firstwordd = explode(' ',$titHome);
			$firstword = explode(' ',$imgTitle);
			
		if ($pic %3 == 1){
			if ($pic == 1 || $pic == 7){echo '<div class="ads">'.$ads728.'</div>';}else{}
			echo'<div class="li-cont">';
			echo'<li><a href="'.$imgUrl.'" rel="nofollow" class="k" ><img height="300" width="300" src="'.$imgUrl.'" alt="'.$imgTitle.' on '.$titHome.'" title="'.ucwords(strtolower($imgTitle)).'" onError="this.onerror=null;this.src=\''.$img[2].'\';"/></a>
			<div class="home-img-title"><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($imgTitle)).'">'.ucwords(strtolower($imgTitle)).'</a></div>
			<div class="home-img-tag">Posted on <a href="'.$siteurl.'/'.strtolower($firstwordd[0]).'/'.sanitize_title_with_dashes(strtolower($titHome)).'">'.ucwords($titHome).'</a> by '.spinner($Name).'</div>
			</li>';
		}elseif ($pic %3 == 0 || $pic == $jumlah){
			echo'<li><a href="'.$imgUrl.'" rel="nofollow" class="k" ><img height="300" width="300" src="'.$imgUrl.'" alt="'.$imgTitle.' on '.$titHome.'" title="'.ucwords(strtolower($imgTitle)).'" onError="this.onerror=null;this.src=\''.$img[2].'\';"/>
			<div class="home-img-title"><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($imgTitle)).'">'.ucwords(strtolower($imgTitle)).'</a></div>
			<div class="home-img-tag">Posted on <a href="'.$siteurl.'/'.strtolower($firstwordd[0]).'/'.sanitize_title_with_dashes(strtolower($titHome)).'">'.ucwords($titHome).'</a> by '.spinner($Name).'</div>
			</li>';
			echo'</div>';
		}else{
			echo'<li><a href="'.$imgUrl.'" rel="nofollow" class="k" ><img height="300" width="300" src="'.$imgUrl.'" alt="'.$imgTitle.' on '.$titHome.'" title="'.ucwords(strtolower($imgTitle)).'" onError="this.onerror=null;this.src=\''.$img[2].'\';"/>
			<div class="home-img-title"><a href="'.$siteurl.'/'.strtolower($firstword[0]).'/'.sanitize_title_with_dashes(strtolower($imgTitle)).'">'.ucwords(strtolower($imgTitle)).'</a></div>
			<div class="home-img-tag">Posted on <a href="'.$siteurl.'/'.strtolower($firstwordd[0]).'/'.sanitize_title_with_dashes(strtolower($titHome)).'">'.ucwords($titHome).'</a> by '.spinner($Name).'</div>
			</li>';
		}$pic++;$ads++;
		}
echo'</div>';
	}
}
?>