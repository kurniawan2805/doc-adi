
char LoadSequential(char * FileName);
char SaveSequential(char * FileName);
