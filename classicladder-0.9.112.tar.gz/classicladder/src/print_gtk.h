
void PrintGtk( );
void PrintPreviewGtk( );
