
void DisplaySymbols( );
void OpenSymbolsWindow( GtkAction * ActionOpen, gboolean OpenIt );
void RememberSymbolsWindowPrefs( void );
void SymbolsInitGtk();
