void SetProperty(int NumParam,char * LblParam,char * ValParam, char ReadOnlyPropertie, char SetFocus);
char * GetProperty(int NumParam);
void ShowPropertiesWindow( int Visible );
void PropertiesInitGtk();
