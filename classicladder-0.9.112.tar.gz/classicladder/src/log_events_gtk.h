
void DisplayLogBookEvents( char OnLogContentModified );
gboolean DisplayLogBookEventsFromCsvFile( char * LogBookFileCsv );
void OpenLogBookWindow( GtkAction * ActionOpen, gboolean OpenIt );
void RememberLogBookWindowPrefs( void );
void LogBookInitGtk();
