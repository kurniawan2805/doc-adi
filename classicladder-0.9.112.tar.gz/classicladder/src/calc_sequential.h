void InitSequential( void );
void PrepareSequential( void );
void RefreshSequentialPage( int PageNbr );
