void InitSocketModbusMaster( void );
void ConfigSerialModbusMaster( void );
void CloseSockSlave( int SlaveIndex );
void CloseSocketModbusMaster( void );
void SocketModbusMasterLoop( void );
void GetSocketModbusMasterStats( int SlaveToDisplay, char * Buff );

