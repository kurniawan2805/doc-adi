
char OpenNetworkConfigDialog( void );
void UpdateNetworkConfigValues( void );

