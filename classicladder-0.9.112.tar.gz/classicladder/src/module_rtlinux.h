void CopySizesInfosFromModuleParams( void );

