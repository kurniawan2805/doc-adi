
void AddCustomIconsAndCursors( void );
void UseCustomIcon (char * CursorName);
void DestroyCustomIconsAndCursors( void );
