void SaveSeqElementProperties( void );
void ModifyCurrentSeqPage(void);
void CancelSeqPageEdited(void);
void ApplySeqPageEdited(void);
int SearchTransiElement( StrSequential * pSeqSearch, int PageNumber, int PositionX, int PositionY );
void InitSeqElementsOfPage( int NumPage );
void EditElementInSeqPage(double x,double y);
