
void InitSymbols( void );
StrSymbol * ConvVarNameInSymbolPtr( char * tcVarNameVar );
char * ConvVarNameToSymbol( char * VarNameParam );
char * ConvSymbolToVarName( char * SymbolParam );
