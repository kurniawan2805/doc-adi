

void InitSocketServer( int UseUdpMode, int PortNbr );
void SocketServerTcpMainLoop( void );
void CloseSocketServer( void );

