void OpenConfigWindowGtk( );
void FillComboBoxConfigSlavesList( MyGtkComboBox * pComboBox, char ListForStatsSelect, char CleanUpBefore );
