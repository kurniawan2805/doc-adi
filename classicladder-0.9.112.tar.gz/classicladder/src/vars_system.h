
void InitSystemVars( char HardwareStart );
void UpdateSystemVars( void );

void VerifyAutoAdjustSummerWinterTime( void );

