
void PrintGnome( void );
void PrintPreviewGnome( void );
