
char OpenMonitorSerialConfigDialog( void );
void UpdateMonitorSerialConfigValues( void );
