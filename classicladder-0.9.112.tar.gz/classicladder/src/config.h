int read_config (char * fname);
